# -*- coding: utf-8 -*-
"""1 月文案包 v1 圖檔：2027 W01–W05。沿用 render_dec 的版型。"""
import sys
from render import page, img, C, SAFE, c5cover, c5text, steps, ingredient_rows, PROMO_NOTE, group7, CHAKRA, OUT
from render import ROOT as ROOTART
from render_dec import end, item, promo_cover, sq, SAFE_S, OFF, B, Bs, chak
from playwright.sync_api import sync_playwright

S = {}
TBL = lambda rows: '<div style="flex:1;display:flex;flex-direction:column;gap:20px;margin:36px 0 100px">' + ''.join(
    f'<div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:26px"><div class="serif" style="font-size:44px;color:{C["sage"]};min-width:190px">{a}</div><div class="sub" style="font-size:36px">{b}</div></div>' for a, b in rows) + '</div>'

# ───────── W01 ─────────
p = 'W01/W01_0105_IG圖卡_小寒北方森林_P{}.png'
S[p.format(1)] = c5cover('小寒，<br>北方森林裡的<br>一盞暖燈', '小寒 1/5', C['char'], C['oat'], '')
S[p.format(2)] = page(f"""<div class="serif h2">腰背舒緩<br>的三種植物</div>{ingredient_rows([('黑雲杉', '加拿大的北方森林'), ('杜松果', '像漿果一樣乾淨'), ('薑', '最後的辛暖')])}""", pg='02 / 05')
S[p.format(3)] = page(f"""<div class="serif h2">今晚，<br>換你幫他推背</div>{steps(['取適量在掌心，搓熱', '沿著背的兩側，由下往上慢慢推'])}""", pg='03 / 05')
S[p.format(4)] = page(f"""<div class="serif h2">最後停一下</div>{steps(['雙手停在肩上，一起呼吸 3 次'])}{SAFE}""", pg='04 / 05')
S[p.format(5)] = end('冷冽的森林裡，<br>有一盞暖燈', '這個冬天，<br>你最想幫誰推一推背？', '傳給今晚<br>想幫他推推背的那個人', '05 / 05')

p = 'W01/W01_0107_IG圖卡_PlantSilk多了哪些植物_P{}.png'
S[p.format(1)] = c5cover('同樣的香氣，<br>PlantSilk<br>多了好幾種植物', '認識植物｜PlantSilk', C['sage'], '#fff', '')
S[p.format(2)] = page(f"""<div class="serif h2">陸地上的<br>五種植物油</div>{TBL([('沙棘', '長在高寒乾燥的地方'), ('印加果', '來自亞馬遜'), ('黑種草', '古埃及的珍寶'), ('接骨木', '歐洲的精靈之樹'), ('小麥胚芽', '一小撮才壓得出一點油')])}""", pg='02 / 05')
S[p.format(3)] = page(f"""<div class="serif h2">海裡的<br>兩種植物</div>{ingredient_rows([('翅菜', '寒冷北大西洋的深海褐藻'), ('海茴香', '長在海邊的岩石上')])}""", pg='03 / 05')
S[p.format(4)] = item('手感', '更滋潤、<br>延展更長', '適合一堂課<br>要推很久的手。', '04 / 05')
S[p.format(5)] = end('收藏', '你喜歡清爽一點，<br>還是滋潤一點？', '傳給在沙龍工作的朋友', '05 / 05')

S['W01/W01_0108_FB方圖_一堂課推60分鐘.png'] = sq(f"""<div class="serif" style="font-size:84px;line-height:1.28;margin-top:20px">一堂課<br>推 60 分鐘</div>
  <div class="sub" style="margin-top:40px">按摩師需要一瓶<br>能陪手走完全程的油。</div>
  <div class="small" style="margin-top:36px;opacity:.85">PlantSilk 進階養護按摩油</div>""")

# ───────── W02 ─────────
p = 'W02/W02_0112_IG圖卡_左手右手_P{}.png'
S[p.format(1)] = c5cover('左手 AirTouch，<br>右手 PlantSilk', '小實驗', C['frost'], '#fff', '')
S[p.format(2)] = item('左手', 'AirTouch', '清爽、推得開，<br>抹完很快就乾爽。', '02 / 05')
S[p.format(3)] = item('右手', 'PlantSilk', '滋潤、延展長，<br>推很久都不卡。', '03 / 05')
S[p.format(4)] = page(f"""<div class="serif h2">看你想要<br>哪一種時刻</div>{ingredient_rows([('☀️ 每天', '洗完澡想快一點 → AirTouch'), ('🌙 週末', '想慢慢推 → PlantSilk')])}{SAFE_S}""", pg='04 / 05')
S[p.format(5)] = end('你是<br>左手派<br>還是右手派？', '', '傳給還在猶豫<br>要買哪一條線的朋友', '05 / 05')

p = 'W02/W02_0114_IG圖卡_AirTouch和PlantSilk怎麼選_P{}.png'
S[p.format(1)] = c5cover('AirTouch<br>和 PlantSilk<br>怎麼選？', '一張表看懂', C['linen'], C['char'], '')
S[p.format(2)] = page(f"""<div class="serif h2">AirTouch 居家</div>{TBL([('基底', '荷荷芭、甜杏仁、角鯊烷'), ('手感', '清爽、乾爽得快'), ('適合', '每天用、全家用'), ('價格', '100mL 550／250mL 899')])}""", pg='02 / 05')
S[p.format(3)] = page(f"""<div class="serif h2">PlantSilk 進階養護</div>{TBL([('基底', '再加 5 種植物油<br>＋2 種海洋植物'), ('手感', '滋潤、延展長'), ('適合', '多寵自己、沙龍'), ('價格', '100mL 650／250mL 999')])}""", pg='03 / 05')
S[p.format(4)] = item('兩條線都有', '八個部位<br>的香氣', '頭皮、頸肩、胸背、腹部、<br>腰背、臀腿、小腿、腳底', '04 / 05', extra=OFF)
S[p.format(5)] = end('收藏<br>這張表', '你最常照顧的<br>是哪個部位？', '傳給問過你<br>這兩個差在哪的朋友', '05 / 05')

S['W02/W02_0115_FB方圖_兩條按摩油的設計.png'] = sq(f"""<div class="serif" style="font-size:80px;line-height:1.3;margin-top:20px">每天的，<br>和想多寵自己<br>一點的</div>
  <div class="sub" style="margin-top:36px;line-height:1.8">AirTouch｜清爽<br>PlantSilk｜滋潤</div>""")

# ───────── W03 ─────────
p = 'W03/W03_0119_IG圖卡_冷天的腳底_P{}.png'
S[p.format(1)] = c5cover('冷天的腳底，<br>像香草和焦糖<br>的樹脂香', '大寒前夜', C['char'], C['oat'], '')
S[p.format(2)] = page(f"""<div class="serif h2">晚安足底<br>的三種植物</div>{ingredient_rows([('薰衣草', '柔和地開場'), ('羅馬洋甘菊', '甜甜地接上'), ('安息香', '蘇門答臘的樹脂')])}""", pg='02 / 05')
S[p.format(3)] = page(f"""<div class="serif h2">泡完腳之後</div>{steps(['取適量在掌心，搓熱', '推開在腳底、腳背、腳踝', '用拇指輕輕按一按腳底'])}{SAFE}""", pg='03 / 05')
S[p.format(4)] = c5text('安息香', '割開樹幹後滲出的香脂，<br>聞起來甜甜暖暖的。', '04 / 05')
S[p.format(5)] = end('冬天的<br>小儀式', '你冬天睡前<br>會做什麼小儀式？', '傳給一到冬天<br>腳就冰冰的朋友', '05 / 05')

p = 'W03/W03_0121_IG圖卡_大寒夜10分鐘_P{}.png'
S[p.format(1)] = c5cover('大寒夜的<br>10 分鐘：<br>花、葉、根', '大寒 1/20', C['sage'], C['linen'], img('breath250.png', 'height:600px'))
S[p.format(2)] = item('前 3 分鐘｜花', '薰衣草的花穗', '關掉大燈，<br>手機放遠一點。', '02 / 05')
S[p.format(3)] = item('中間 4 分鐘｜葉', '馬鬱蘭的葉子', '從小腿往上<br>慢慢推開。', '03 / 05', extra=SAFE)
S[p.format(4)] = item('最後 3 分鐘｜根', '岩蘭草的根', '雙手停在膝蓋上，<br>慢慢呼吸。', '04 / 05')
S[p.format(5)] = end('一年也像這樣，<br>從開花<br>走到扎根', '這一年，<br>你最想謝謝自己什麼？', '傳給這一年<br>辛苦了的朋友', '05 / 05')

S['W03/W03_0122_FB方圖_岩蘭草的根.png'] = sq(f"""<div class="serif" style="font-size:80px;line-height:1.3;margin-top:20px">大寒：<br>岩蘭草的根，<br>和一年的尾聲</div>
  <div class="sub" style="margin-top:36px">花在上面，根在下面。</div>""", bg=C['char'], fg=C['oat'])

# ───────── W04 ─────────
p = 'W04/W04_0126_IG圖卡_七種顏色的年禮_P{}.png'
S[p.format(1)] = c5cover('今年的年禮，<br>送一種顏色', '年禮', C['oat'], C['char'], group7)
S[p.format(2)] = page(f'<div class="serif h2">七種心情</div>{chak(CHAKRA[:4])}', pg='02 / 05')
S[p.format(3)] = page(f'<div class="serif h2">選一個給他</div>{chak(CHAKRA[4:])}', pg='03 / 05')
S[p.format(4)] = item('包年禮', '一瓶，<br>配一張手寫小卡', '寫上你想對他說的<br>那個詞。', '04 / 05', art=group7)
S[p.format(5)] = end('你想送<br>哪一種顏色？', '送給誰？', '傳給還沒想好<br>年禮的朋友', '05 / 05')

p = 'W04/W04_0128_IG圖卡_春節送禮清單_P{}.png'
S[p.format(1)] = c5cover('送長輩、<br>送同事、<br>送自己', '春節送禮清單', C['sage'], '#fff', img('breath250.png', 'height:600px'))
S[p.format(2)] = item('送長輩', '一夜放鬆<br>250mL', '一天忙完、坐下來的那一刻。<br>花香慢慢沉成木質。', '02 / 05', art=Bs)
S[p.format(3)] = item('送同事', '七脈輪<br>按摩油 100mL', '七種心情，<br>讓對方挑今年想要的那一個。', '03 / 05', art=group7)
S[p.format(4)] = item('送自己', 'PlantSilk 系列', '一整年都在照顧別人，<br>這次多寵自己一點。', '04 / 05', extra=OFF)
S[p.format(5)] = end('收藏<br>這份清單', '留言送誰，<br>我幫你挑', '傳給一起準備年貨的家人', '05 / 05',
                     note='<div class="note" style="margin-top:12px">春節出貨時間請看置頂公告（到貨時間以物流為準）</div>')

S['W04/W04_0129_FB方圖_送會每天用的禮物.png'] = sq(f"""<div class="serif" style="font-size:80px;line-height:1.3;margin-top:20px">送一份<br>會每天打開的<br>禮物</div>
  <div class="sub" style="margin-top:36px">附一張小卡：今年也辛苦了。</div>""")
S['W04/W04_0130_單圖_春節出貨公告.png'] = page(f"""<div><span class="pill" style="background:{C['amber']};color:#fff">春節出貨公告</span></div>
  <div class="serif h1" style="margin-top:50px">春節<br>出貨時間</div>
  {ingredient_rows([('年前', '最後出貨日看貼文說明'), ('春節', '暫停出貨，仍可下單'), ('開工', '依訂單順序出貨')])}
  <div class="note" style="margin-bottom:60px">到貨時間以物流為準</div>""", bg=C['oat'])

# ───────── W05 ─────────
S['W05/W05_0201_單圖_22年前囤貨清單.png'] = page(f"""<div><span class="pill" style="background:{C['amber']};color:#fff">明天 2.2</span></div>
  <div class="serif h1" style="margin-top:50px">年前最後<br>囤貨清單</div>
  {ingredient_rows([('經典六款', '年夜飯後，全家輪流用'), ('七脈輪', '還沒送出的年禮'), ('PURA+', '洗完臉的最後一步')])}
  <div class="note" style="margin-bottom:6px">限時特賣場次時段看限動</div>{PROMO_NOTE}""", bg=C['oat'])
S['W05/W05_0202_單圖_22開跑.png'] = page(f"""<div><span class="pill" style="background:{C['amber']};color:#fff">2.2 今天開跑</span></div>
  <div class="serif h1" style="margin-top:50px">2.2<br>今天開跑</div>
  <div class="sub" style="margin-top:30px">限時特賣場次時段看限動</div>
  <div class="note" style="margin-top:auto;margin-bottom:6px">想在過年前送到，記得今天下單（到貨時間以物流為準）</div>{PROMO_NOTE}""", bg=C['oat'])

p = 'W05/W05_0204_IG圖卡_立春幫爸媽按手_P{}.png'
S[p.format(1)] = c5cover('立春，<br>幫爸媽<br>按 3 分鐘手', '立春 2/4', C['sage'], C['linen'], img('breath250.png', 'height:600px'))
S[p.format(2)] = c5text('這雙手<br>煮了一整年<br>的飯', '這次換你。', '02 / 05')
S[p.format(3)] = page(f"""<div class="serif h2">先暖手</div>{steps(['取適量按摩油在掌心，搓熱', '從手掌往指尖輕輕推'])}""", pg='03 / 05')
S[p.format(4)] = page(f"""<div class="serif h2">再慢慢按</div>{steps(['一根一根手指慢慢按', '雙手包住他的手，停一下'])}{SAFE}""", pg='04 / 05')
S[p.format(5)] = end('像把冬天的陽光<br>握在手裡', '你今年回家，<br>最想幫誰按？', '傳給今年會回家<br>過年的兄弟姊妹', '05 / 05',
                     note='<div class="note" style="margin-top:12px">香氣：美體勻潤｜檸檬、甜橙的果皮香</div>')

S['W05/W05_0205_FB方圖_除夕桔子的吉.png'] = sq(f"""<div class="serif" style="font-size:84px;line-height:1.3;margin-top:20px">除夕快樂</div>
  <div class="serif" style="font-size:60px;line-height:1.4;margin-top:20px">桔子的吉，<br>和一家人的香氣</div>
  <div class="sub" style="margin-top:30px">剝開果皮的那一刻，<br>整個客廳都是香甜的味道。</div>""", bg=C['oat'], fg=C['char'])


def main(only=None):
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        for fn, html in S.items():
            if only and only not in fn:
                continue
            out = OUT / fn
            out.parent.mkdir(parents=True, exist_ok=True)
            w = int(html.split('--w:')[1].split('px')[0]); h = int(html.split('--h:')[1].split('px')[0])
            pg = b.new_page(viewport={'width': w, 'height': h})
            pg.set_content(html, wait_until='load'); pg.wait_for_timeout(200)
            pg.screenshot(path=str(out), clip={'x': 0, 'y': 0, 'width': w, 'height': h}); pg.close()
        b.close()
    print(len(S), 'defined')

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else None)
