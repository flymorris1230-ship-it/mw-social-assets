# -*- coding: utf-8 -*-
"""11 月–1 月知識點版（v6）總審查頁：每則標出 💡 知識點與敏感話題處理。"""
import sys, io, base64, html, json
sys.argv = [sys.argv[0], '__none__']
from PIL import Image
import render, render_dec, render_jan, render_kp, kp
from kp_gate import check

def imgs_for(p):
    d = p['date']; k = d[5:].replace('-', '')
    if p['sens']:
        src = render_kp; keys = [f for f in render_kp.S if f'_{k}_' in f]
    else:
        src = render if d < '2026-12-01' else (render_dec if d < '2027-01-02' else render_jan)
        keys = [f for f in src.S if f'_{k}_' in f and '限動' not in f and not ('Reels封面' in f and any('IG圖卡' in g and f'_{k}_' in g for g in src.S))]
    return src, keys

css = """:root{--bg:#F5F3F0;--fg:#3A3A36;--card:#fff;--acc:#335C4F;--mut:#6b6b64;--line:#E3D5C3;--warn:#C4703E;--kp:#EAF1EC}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#1f2120;--fg:#ecebe6;--card:#2a2d2b;--acc:#8fbfae;--mut:#a9a8a0;--line:#3b3f3c;--kp:#25332c}}
:root[data-theme="dark"]{--bg:#1f2120;--fg:#ecebe6;--card:#2a2d2b;--acc:#8fbfae;--mut:#a9a8a0;--line:#3b3f3c;--kp:#25332c}
body{margin:0;background:var(--bg);color:var(--fg);font-family:'Noto Sans TC',system-ui,sans-serif;line-height:1.6}
.wrap{max-width:1100px;margin:0 auto;padding:24px 16px 80px}h1{font-size:26px;margin:0 0 6px}.lead{color:var(--mut);font-size:14px;margin:0 0 14px}
.rules{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 18px;margin:0 0 20px;font-size:14px}.rules b{color:var(--acc)}
.mon{font-size:20px;margin:28px 0 10px;color:var(--acc)}
.post{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;margin:0 0 18px}.post.s{border-left:6px solid var(--warn)}
.post h2{font-size:18px;margin:0 0 4px}.meta{font-size:13px;color:var(--mut);margin-bottom:8px}
.tag{display:inline-block;font-size:12px;padding:2px 10px;border-radius:999px;margin:0 6px 4px 0;background:var(--acc);color:#fff}.tag.warn{background:var(--warn)}
.kp{background:var(--kp);border-radius:10px;padding:10px 12px;font-size:14px;margin:8px 0}
.imgs{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin:10px 0}.imgs img{width:100%;border-radius:8px;border:1px solid var(--line);cursor:zoom-in;display:block}
details{margin-top:6px}summary{cursor:pointer;color:var(--acc);font-size:14px}pre{white-space:pre-wrap;font-family:inherit;font-size:14px;background:var(--bg);padding:12px;border-radius:10px;margin:8px 0 0}
#lb{position:fixed;inset:0;background:rgba(0,0,0,.85);display:none;align-items:center;justify-content:center;z-index:9;padding:16px}#lb img{max-width:100%;max-height:100%;border-radius:8px}"""

nS = sum(1 for p in kp.ALL if p['sens'])
out = [f"<title>MW 每週圖文審查</title><style>{css}</style><div class='wrap'>",
       "<h1>MW 每週圖文審查｜11 月–1 月知識點版 v6 待審</h1>",
       f"<p class='lead'>2026-11-05 → 2027-02-05，共 {len(kp.ALL)} 則（{sum(('ig' in p)+('fb' in p) for p in kp.ALL)} 份文案）。全部重新送審；狀態都是待審，你核可後才會發。</p>",
       f"<div class='rules'><b>v6 規則</b>：① 每則文案都有一段「💡 精油小知識」（綠底標示），全部通過知識點檢查。② <b>敏感話題 {nS} 則</b>（橘色邊框）改成純知識貼文：不寫商品名、價格、導流結尾、商品 hashtag，圖上不放瓶身，佇列的導流連結也清空。敏感話題 = 睡眠、紓壓／情緒、身體部位舒緩、冷／暖身、大腦與嗅覺科學、精油濃度安全。③ 其他貼文照常連結商品；另外拿掉 12/4 床頭句、12/8 和 12/22 的暖身舒活描述（文案和圖都改了）。</div>"]
cur = ''
for p in kp.ALL:
    mon = p['date'][:7]
    if mon != cur:
        cur = mon; out.append(f"<div class='mon'>{mon}</div>")
    src, keys = imgs_for(p)
    rs = check(p)
    tags = ''.join(f"<span class='tag{' warn' if r['lint'] != '通過' else ''}'>{r['plat']} {r['lint']}</span>" for r in rs)
    tags += ''.join(f"<span class='tag'>{r['plat']} 知識點 ✓</span>" for r in rs if not r['fails'])
    if p['sens']:
        tags += f"<span class='tag warn'>敏感話題：{html.escape(p['sens'])}｜不連結商品</span>"
    ims = ''
    for f in keys:
        im = Image.open(src.OUT / f).convert('RGB'); im.thumbnail((540, 960)); b = io.BytesIO(); im.save(b, 'JPEG', quality=76)
        ims += f"<img src='data:image/jpeg;base64,{base64.b64encode(b.getvalue()).decode()}' alt=''>"
    if not keys:
        ims = "<div class='meta'>（這則沒有本地圖檔：11/14 用 Canva 草稿、待製作）</div>"
    txt = ''.join(f"<details{' open' if i == 0 else ''}><summary>{n} 文案</summary><pre>{html.escape(p[kk])}</pre></details>"
                  for i, (kk, n) in enumerate([(x, y) for x, y in (('ig', 'IG'), ('fb', 'FB')) if x in p]))
    out.append(f"<section class='post{' s' if p['sens'] else ''}'><h2>{p['date']}｜{html.escape(p['plat'])}｜{html.escape(p['title'])}</h2>"
               f"<div class='meta'>{p.get('week', '')}{'｜改圖 ' + str(len(keys)) + ' 張（v6 新圖）' if p['sens'] else ''}</div>{tags}"
               f"<div class='kp'>💡 {html.escape(p['kp'])}</div><div class='imgs'>{ims}</div>{txt}</section>")
out.append("<div id='lb' onclick=\"this.style.display='none'\"><img alt=''></div><script>document.querySelectorAll('.imgs img').forEach(i=>i.onclick=()=>{const l=document.getElementById('lb');l.querySelector('img').src=i.src;l.style.display='flex'})</script></div>")
open('MW_每週圖文審查.html', 'w').write('\n'.join(out))
print('ok', len(kp.ALL))
