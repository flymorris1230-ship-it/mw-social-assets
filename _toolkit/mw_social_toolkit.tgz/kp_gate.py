# -*- coding: utf-8 -*-
"""K 閘門（v6）：K1 每則文案恰有一個 💡 精油小知識；K2 敏感話題貼文不連結商品；K3 mw_lint 無 RED。"""
import re, json, sys
import kp, mw_lint

PRODUCTS = ['七脈輪', 'AirTouch', 'PlantSilk', 'PURA', '經典按摩油', '清新舒緩', '淨立舒緩', '美體勻潤', '一夜放鬆',
            '胸頸自信', '暖身舒活', '腰背舒緩', '晚安足底', '和順腹', '自信光能', '根源安定', '芳療級', 'SMOKOR', 'MOR',
            '250mL', '100mL']
LINKS = [kp.IGEND, kp.FBEND, '蝦皮', '商品連結', '主頁', '下單', '購物車', '優惠', '限時特賣']
PRICE = re.compile(r'(\$|NT|元|\b\d{3,4}\b(?!\s*(年|分鐘|mL)))')

def check(p):
    res = []
    for kk, kind in (('ig', 'IG'), ('fb', 'FB')):
        if kk not in p:
            continue
        t = p[kk]
        r = {'date': p['date'], 'plat': kind, 'title': p['title'], 'sens': p['sens'], 'fails': []}
        n = t.count(kp.H)
        if n != 1:
            r['fails'].append(f'K1 知識點數量 {n}')
        lint = mw_lint.scan(t, kind)
        if lint['RED']:
            r['fails'].append('K3 lint RED ' + '、'.join(x['詞'] for x in lint['RED']))
        if p['sens']:  # 敏感話題刻意不放導流結尾
            lint['CHECK'] = [c for c in lint['CHECK'] if '缺固定結尾' not in c]
        r['lint'] = mw_lint.verdict(lint).split('（')[0]
        r['yellow'] = lint['YELLOW']; r['check'] = lint['CHECK']
        if p['sens']:
            hit = [w for w in PRODUCTS + LINKS if w in t]
            body = re.sub(r'📚 參考資料[\s\S]*?(?=\n\n💬|\n\n#|$)', '', t)
            pr = [m.group(0) for m in PRICE.finditer(body) if m.group(0) not in ('2009', '2014', '263', '290', '119')]
            if hit:
                r['fails'].append('K2 敏感話題含商品／導流：' + '、'.join(hit))
            if pr:
                r['fails'].append('K2 敏感話題含價格／數字：' + '、'.join(pr))
        res.append(r)
    return res

if __name__ == '__main__':
    R = [r for p in kp.ALL for r in check(p)]
    bad = [r for r in R if r['fails']]
    for r in R:
        print(('FAIL ' if r['fails'] else 'PASS ') + r['date'][5:], r['plat'], ('🔴' if r['sens'] else '  '), r['lint'], r['title'][:24], '｜'.join(r['fails']), ('CHECK:' + '、'.join(r['check'])) if r['check'] else '')
    print(len(R) - len(bad), '/', len(R), 'PASS')
    json.dump(R, open('kp_gate_result.json', 'w'), ensure_ascii=False, indent=1)
