import kp
P = [p for p in kp.ALL if p['sens']]
