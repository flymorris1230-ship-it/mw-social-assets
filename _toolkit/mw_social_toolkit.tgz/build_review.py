import json, base64, io, html, sys, importlib
from PIL import Image
import mw_lint
cmod, rmod, gres, outfn, title, lead = sys.argv[1:7]
copy=importlib.import_module(cmod); r=importlib.import_module(rmod)
g={x['檔名']:x for x in json.load(open(gres))}
css=open('review_css.txt').read() if False else """
:root{--bg:#F5F3F0;--fg:#3A3A36;--card:#fff;--acc:#335C4F;--mut:#6b6b64;--line:#E3D5C3}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#1f2120;--fg:#ecebe6;--card:#2a2d2b;--acc:#8fbfae;--mut:#a9a8a0;--line:#3b3f3c}}
:root[data-theme="dark"]{--bg:#1f2120;--fg:#ecebe6;--card:#2a2d2b;--acc:#8fbfae;--mut:#a9a8a0;--line:#3b3f3c}
body{margin:0;background:var(--bg);color:var(--fg);font-family:'Noto Sans TC',system-ui,sans-serif;line-height:1.6}
.wrap{max-width:1100px;margin:0 auto;padding:24px 16px 80px}h1{font-size:26px;margin:0 0 6px}.lead{color:var(--mut);font-size:14px;margin:0 0 20px}
.post{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;margin:0 0 20px}.post h2{font-size:18px;margin:0 0 4px}.meta{font-size:13px;color:var(--mut);margin-bottom:10px}
.tag{display:inline-block;font-size:12px;padding:2px 10px;border-radius:999px;margin-right:6px;background:var(--acc);color:#fff}.tag.warn{background:#C4703E}
.imgs{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin:12px 0}.imgs figure{margin:0}.imgs img{width:100%;border-radius:8px;border:1px solid var(--line);cursor:zoom-in;display:block}
.imgs figcaption{font-size:11px;color:var(--mut);margin-top:3px;word-break:break-all}details{margin-top:8px}summary{cursor:pointer;color:var(--acc);font-size:14px}
pre{white-space:pre-wrap;font-family:inherit;font-size:14px;background:var(--bg);padding:12px;border-radius:10px;margin:8px 0 0}
#lb{position:fixed;inset:0;background:rgba(0,0,0,.85);display:none;align-items:center;justify-content:center;z-index:9;padding:16px}#lb img{max-width:100%;max-height:100%;border-radius:8px}"""
out=[f"<title>{title}</title><style>{css}</style><div class='wrap'><h1>{title}</h1><p class='lead'>{lead}</p>"]
files=list(r.S.keys())
for p in copy.P:
    k=p['date'][5:].replace('-',''); fs=[f for f in files if f'_{k}_' in f]
    verd=[kind+' '+mw_lint.verdict(mw_lint.scan(p[kk],kind)).split('（')[0] for kk,kind in (('ig','IG'),('fb','FB')) if kk in p]
    tags=''.join(f"<span class='tag{' warn' if '待檢' in v else ''}'>{v}</span>" for v in verd)
    ims=''
    for f in fs:
        im=Image.open(r.OUT/f).convert('RGB'); im.thumbnail((540,960)); b=io.BytesIO(); im.save(b,'JPEG',quality=78)
        ims+=f"<figure><img src='data:image/jpeg;base64,{base64.b64encode(b.getvalue()).decode()}' alt=''><figcaption>{html.escape(f.split('/')[-1])}｜{g[f]['自動閘門']}</figcaption></figure>"
    txt=''.join(f"<details{' open' if i==0 else ''}><summary>{n} 文案</summary><pre>{html.escape(p[kk])}</pre></details>" for i,(kk,n) in enumerate([(x,y) for x,y in (('ig','IG'),('fb','FB')) if x in p]))
    out.append(f"<section class='post'><h2>{p['date']}｜{html.escape(p['plat'])}｜{html.escape(p['title'])}</h2><div class='meta'>{p['week']}｜{p.get('fmt','')}{'｜'+p['orig'] if p.get('orig') else ''}｜轉傳／FB問題：{html.escape(p['share'])}</div>{tags}<div class='imgs'>{ims}</div>{txt}</section>")
out.append("</div><div id='lb' onclick=\"this.style.display='none'\"><img id='lbi' alt=''></div><script>document.querySelectorAll('.imgs img').forEach(i=>i.onclick=()=>{lbi.src=i.src;lb.style.display='flex'})</script>")
open(outfn,'w',encoding='utf-8').write(''.join(out)); print('ok')
