# -*- coding: utf-8 -*-
"""12 月文案包 v2（11/4）圖檔：W49–W53。沿用 render.py 的版型與色票；Reels 改 5P 圖卡輪播。"""
import sys
from render import page, img, C, SAFE, c5cover, c5text, c5end, steps, ingredient_rows, PROMO_NOTE, group7, CHAKRA, ISO, OUT
from render import ROOT as ROOTART
from playwright.sync_api import sync_playwright

S = {}
B = img('breath250.png', 'height:560px')
Bs = img('breath250.png', 'height:460px')
SAFE_S = ('<div class="note" style="margin-top:24px">第一次使用先在手臂內側小面積試用｜避開眼周與黏膜｜'
          '孕期、哺乳期或特殊體質，請先諮詢醫師</div>')
OFF = '<div class="note" style="margin-top:auto;margin-bottom:60px">實際優惠以蝦皮頁面為準</div>'

def end(title, ask, share, pg, safe=True, note=''):
    a = f'<div class="box" style="background:{C["sage"]};color:#fff;margin-top:48px"><div class="sub">💬 {ask}</div></div>' if ask else ''
    return page(f"""<div class="serif h1" style="margin-top:80px">{title}</div>{a}
  <div class="box" style="background:#fff;margin-top:24px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 {share}</div></div>
  <div class="small" style="margin-top:30px">🔗 商品連結在主頁｜限動也有連結貼紙</div>{SAFE_S if safe else ''}{note}""", bg=C['oat'], pg=pg)

def item(kicker, head, body, pg, art='', bg=None, fg=None, extra=''):
    a = f'<div style="position:absolute;left:0;right:0;bottom:110px;display:flex;justify-content:center">{art}</div>' if art else ''
    return page(f"""<div><span class="pill" style="background:{C['sage']};color:#fff">{kicker}</span></div>
  <div class="serif h1" style="font-size:84px;margin-top:44px">{head}</div>
  <div class="h3" style="margin-top:36px;line-height:1.6">{body}</div>{extra}{a}""", bg=bg or C['linen'], fg=fg or C['char'], pg=pg)

def promo_cover(title, kicker, pg, art=''):
    return page(f"""<div><span class="pill" style="background:{C['amber']};color:#fff">{kicker}</span></div>
  <div class="serif h1" style="margin-top:56px;font-size:96px">{title}</div>
  <div style="position:absolute;left:0;right:0;bottom:110px;display:flex;justify-content:center">{art}</div>""", bg=C['oat'], pg=pg)

def sq(inner, bg=C['sage'], fg='#fff'):
    return page(inner, 1080, 1080, bg, fg)

# ───────── W49 ─────────
p = 'W49/W49_1201_IG圖卡_送一段時間_P{}.png'
S[p.format(1)] = c5cover('送一瓶油，<br>其實是送<br>一段時間', '聖誕送禮｜芳療師說', C['sage'], '#fff', img('breath250.png', 'height:620px'))
S[p.format(2)] = c5text('收到的人<br>會在這些時刻<br>打開它', '洗完澡、坐在床邊、<br>把燈調暗的那幾分鐘。', '02 / 05', art=Bs)
S[p.format(3)] = page(f"""<div class="serif h2">一夜放鬆<br>裡的三種植物</div>{ingredient_rows([('花穗', '薰衣草'), ('葉', '馬鬱蘭'), ('根', '岩蘭草')])}""", pg='03 / 05')
S[p.format(4)] = page(f"""<div class="serif h2">我會這樣包</div>{steps(['一瓶一夜放鬆 250mL', '一張手寫小卡', '素色包裝紙，讓香氣當主角'])}
  <div class="box" style="background:{C['sage']};color:#fff;margin-bottom:100px"><div class="sub">✍️ 今天也辛苦了，<br>晚上留 5 分鐘給自己。</div></div>""", pg='04 / 05')
S[p.format(5)] = end('收藏<br>這個送禮靈感', '你今年聖誕<br>想送給誰？', '傳給今年要抽<br>交換禮物的朋友', '05 / 05')

p = 'W49/W49_1203_IG圖卡_聖誕送禮指南_P{}.png'
S[p.format(1)] = c5cover('聖誕送禮，<br>依對象<br>挑一瓶', '聖誕送禮指南', C['frost'], '#fff', img('breath250.png', 'height:600px'), pg='01 / 07')
S[p.format(2)] = c5text('我挑禮物<br>只想一件事', '對方會在<br>什麼時刻打開它？', '02 / 07', art=group7)
S[p.format(3)] = item('送同事', '七脈輪<br>按摩油 100mL', '七種心情、七種香氣，<br>讓對方挑今天想要的那一瓶。', '03 / 07', art=group7)
S[p.format(4)] = item('送媽媽', '一夜放鬆<br>250mL', '一天忙完、坐下來的那一刻。<br>花香慢慢沉成木質。', '04 / 07', art=Bs)
S[p.format(5)] = item('送另一半', '經典按摩油<br>六款 250mL', '一起聞，<br>挑一款兩個人都喜歡的香氣。', '05 / 07', art=Bs)
S[p.format(6)] = item('送愛保養的朋友', 'PURA+<br>任選 2 入 699', '角鯊烷、杏仁酸 PHA、B3 精華，<br>挑兩支。活動至 12/31。', '06 / 07', extra=OFF)
S[p.format(7)] = end('收藏<br>這份清單', '留言送誰＋預算，<br>我幫你配', '傳給還沒想好<br>聖誕禮物的那位朋友', '07 / 07',
                     note='<div class="note" style="margin-top:12px">想在聖誕前送到，記得早點下單（到貨時間以物流為準）</div>')

S['W49/W49_1204_FB方圖_一夜放鬆三種植物.png'] = sq(f"""<div class="serif" style="font-size:80px;line-height:1.3;margin-top:20px">花穗、葉子，<br>和埋在土裡的根</div>
  <div class="sub" style="margin-top:40px;line-height:1.9">🌸 薰衣草｜花穗<br>🌿 馬鬱蘭｜葉<br>🌱 岩蘭草｜根</div>
  <div class="small" style="margin-top:30px;opacity:.85">一夜放鬆，聞起來是有順序的</div>""")

# ───────── W50 ─────────
p = 'W50/W50_1208_IG圖卡_大雪洗完澡3分鐘_P{}.png'
S[p.format(1)] = c5cover('大雪過後，<br>洗完澡的<br>3 分鐘', '大雪｜冬季用油', C['frost'], '#fff', img('breath250.png', 'height:600px'), pg='01 / 07')
S[p.format(2)] = c5text('浴室<br>還有熱氣', '皮膚帶著一點水氣，<br>從頭到腳把油抹好。', '02 / 07', art=Bs)
S[p.format(3)] = item('臉', 'PURA+<br>角鯊烷', '少量按壓全臉。', '03 / 07')
S[p.format(4)] = item('肩頸', '芳療級<br>身體按摩油', '掌心溫熱後輕推。', '04 / 07')
S[p.format(5)] = item('手肘・膝蓋・腳跟', '容易乾的地方<br>多抹一層', '冬天最常被忘記的地方。', '05 / 07')
S[p.format(6)] = item('全身', '經典按摩油<br>六款 250mL', '大面積用大瓶。<br>香氣挑你聞了<br>最想多停留一下的那一款。', '06 / 07', art=Bs)
S[p.format(7)] = page(f"""<div class="serif h1" style="margin-top:60px">收藏</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:40px"><div class="sub">💬 你身上最容易乾的是哪裡？</div></div>
  <div class="box" style="background:#fff;margin-top:24px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 傳給一到冬天就喊乾的朋友</div></div>{SAFE}""", bg=C['oat'], pg='07 / 07')

p = 'W50/W50_1210_IG圖卡_1212冬季購物車_P{}.png'
S[p.format(1)] = promo_cover('1212 倒數 2 天，<br>我的<br>冬季購物車', '1212 倒數', '01 / 05', img('breath250.png', 'height:600px'))
S[p.format(2)] = item('下班後的肩頸', '芳療級<br>身體按摩油 100mL', '下班後的那幾分鐘，<br>留給肩頸。', '02 / 05')
S[p.format(3)] = item('洗完臉的最後一步', 'PURA+<br>任選 2 入 699', '我選角鯊烷＋B3 精華。', '03 / 05', extra=OFF)
S[p.format(4)] = item('全家洗完澡', '經典按摩油<br>六款 250mL', '一家人輪流用，<br>各挑各的香氣。', '04 / 05', art=Bs)
S[p.format(5)] = page(f"""<div class="serif h1" style="margin-top:60px;font-size:90px">12/12 當天<br>有限時特賣場次</div>
  <div class="sub" style="margin-top:24px">時段看限動｜先按關注，開賣通知不漏接</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:36px"><div class="sub">💬 留言你的購物車裡有什麼</div></div>
  <div class="box" style="background:#fff;margin-top:24px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 傳給一起湊 1212 的朋友</div></div>{SAFE_S}{PROMO_NOTE}""", bg=C['oat'], pg='05 / 05')

S['W50/W50_1211_FB方圖_精油不是越濃越好.png'] = sq(f"""<div class="serif" style="font-size:96px;line-height:1.25;margin-top:30px">精油<br>不是越濃越好</div>
  <div class="sub" style="margin-top:44px">一小滴，就是一大把植物。<br>按摩油要的是剛好。</div>
  <div class="small" style="margin-top:40px;opacity:.85">濃度依《Essential Oil Safety》皮膚使用建議訂定</div>""")

S['W50/W50_1212_IG單圖_1212開跑.png'] = page(f"""<div><span class="pill" style="background:{C['amber']};color:#fff">1212 今天開跑</span></div>
  <div class="serif h1" style="margin-top:50px">1212<br>今天開跑</div>
  {ingredient_rows([('限時特賣', '場次時段看限動'), ('PURA+', '任選 2 入 699（至 12/31）'), ('經典六款', '250mL，冬天全家輪流用')])}
  <div class="note" style="margin-bottom:6px">想在聖誕前送到，記得今天下單（到貨時間以物流為準）</div>{PROMO_NOTE}""", bg=C['oat'])

# ───────── W51 ─────────
p = 'W51/W51_1215_IG圖卡_角鯊烷是什麼_P{}.png'
S[p.format(1)] = c5cover('冬天上妝卡粉，<br>常常是少了<br>最後一步', '認識成分｜角鯊烷', C['linen'], C['char'], '', pg='01 / 07')
S[p.format(2)] = c5text('角鯊烷<br>是什麼？', '保養品裡常見的油相成分。<br>PURA+ 這支全成分<br>只有植物來源的 Squalane。', '02 / 07')
S[p.format(3)] = item('用法 1', '化妝水之後', '少量按壓全臉。', '03 / 07')
S[p.format(4)] = item('用法 2', '乳霜裡<br>加 1 滴', '讓乳霜更好推開。', '04 / 07')
S[p.format(5)] = item('用法 3', '兩頰、嘴角<br>乾的時候', '不用擦全臉，<br>少量加強就好。', '05 / 07')
S[p.format(6)] = item('PURA+ 角鯊烷', '單買 396<br>任選 2 入 699', '活動至 12/31。', '06 / 07', extra=OFF)
S[p.format(7)] = page(f"""<div class="serif h1" style="margin-top:60px">收藏</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:40px"><div class="sub">💬 你冬天臉上最困擾的是什麼？</div></div>
  <div class="box" style="background:#fff;margin-top:24px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 傳給冬天上妝總是卡粉的朋友</div></div>{SAFE}""", bg=C['oat'], pg='07 / 07')

p = 'W51/W51_1217_IG圖卡_MW的2026_P{}.png'
S[p.format(1)] = c5cover('MW 的<br>2026', '年度回顧', C['sage'], '#fff', img('breath250.png', 'height:620px'))
S[p.format(2)] = c5text('這一年<br>我們只想<br>做好一件事', '讓你下單前<br>就看得懂。', '02 / 05', art=Bs)
S[p.format(3)] = page(f"""<div class="serif h2">商品頁<br>重新整理了</div>{ingredient_rows([('植物', '每一瓶是什麼植物'), ('部位', '香氣在植物的哪裡'), ('時刻', '適合什麼時刻用'), ('安心', '怎麼用才安心')])}""", pg='03 / 05')
S[p.format(4)] = page(f"""<div class="serif h2" style="margin-top:40px">每一瓶，<br>都在我們自己的<br>工廠完成</div>
  <div style="display:flex;justify-content:center;margin-top:90px">{ISO}</div>""", bg=C['sage'], fg='#fff', pg='04 / 05')
S[p.format(5)] = end('謝謝你<br>這一年', '留言你今年<br>最常打開的那一瓶', '傳給這一年<br>陪你一起用油的人', '05 / 05', safe=False)

S['W51/W51_1218_FB方圖_PURA三支怎麼排.png'] = sq(f"""<div class="serif" style="font-size:84px;line-height:1.25;margin-top:10px">PURA+ 三支<br>怎麼排？</div>
  <div class="sub" style="margin-top:36px;line-height:1.8">☀️ 白天｜B3 精華 → 角鯊烷<br>🌙 每週 2–3 晚｜杏仁酸 PHA</div>
  <div class="small" style="margin-top:24px;opacity:.85">先水、後油｜使用杏仁酸期間白天做好防曬</div>""")

# ───────── W52 ─────────
p = 'W52/W52_1222_IG圖卡_冬至夜_P{}.png'
S[p.format(1)] = c5cover('冬至夜，<br>一年最長的夜晚<br>留給自己', '冬至 12/22', C['char'], C['oat'], img('breath250.png', 'height:580px'), pg='01 / 07')
S[p.format(2)] = c5text('把這一年<br>慢慢收起來', '吃完湯圓、<br>泡個熱水澡。', '02 / 07')
S[p.format(3)] = item('1', '泡澡<br>15 分鐘', '水溫自己覺得舒服就好。', '03 / 07')
S[p.format(4)] = item('2', '洗完臉', 'B3 精華 → 角鯊烷', '04 / 07')
S[p.format(5)] = item('3', '身體｜經典按摩油', '六款香氣，<br>挑你最想聞的那一款。', '05 / 07', art=Bs)
S[p.format(6)] = item('4', '寫下 3 件<br>今年想謝謝<br>自己的事', '', '06 / 07')
S[p.format(7)] = page(f"""<div class="serif h1" style="margin-top:60px">收藏，<br>今晚一起做</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:40px"><div class="sub">💬 你今年最想謝謝自己的一件事？</div></div>
  <div class="box" style="background:#fff;margin-top:24px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 傳給今年辛苦了的那個人</div></div>{SAFE}""", bg=C['oat'], pg='07 / 07')

p = 'W52/W52_1224_IG圖卡_平安夜3分鐘_P{}.png'
S[p.format(1)] = c5cover('今晚不用大禮，<br>幫他按<br>3 分鐘肩膀', '平安夜 12/24', C['sage'], C['linen'], img('breath250.png', 'height:600px'))
S[p.format(2)] = page(f"""<div class="serif h2">先暖手</div>{steps(['取適量按摩油在掌心，搓熱', '從頸後往肩膀兩側輕推，慢一點'])}""", pg='02 / 05')
S[p.format(3)] = page(f"""<div class="serif h2">最後停一下</div>{steps(['雙手停在肩上，一起慢慢呼吸 3 次'])}{SAFE}""", pg='03 / 05')
S[p.format(4)] = item('今晚的香氣', '胸頸自信', '玫瑰天竺葵的葉子、<br>依蘭的花，<br>柔軟的花香。', '04 / 05', art=Bs)
S[p.format(5)] = end('聖誕快樂', '你今晚想幫誰按？', '傳給你今晚<br>想幫他按肩膀的人', '05 / 05')

S['W52/W52_1225_FB方圖_聖誕快樂2027.png'] = sq(f"""<div class="serif" style="font-size:76px;line-height:1.3;margin-top:10px">聖誕快樂<br>2027，我們想繼續<br>做的 3 件事</div>
  <div class="sub" style="margin-top:36px;line-height:1.9">① 多講植物<br>② 多講怎麼用<br>③ 把每一瓶做好</div>""")

# ───────── W53 ─────────
p = 'W53/W53_1229_IG圖卡_PURA年末提醒_P{}.png'
S[p.format(1)] = promo_cover('PURA+<br>任選 2 入 699<br>12/31 結束', '年末優惠提醒', '01 / 05')
S[p.format(2)] = item('喜歡最後用油收尾', '角鯊烷', '很輕的一層油。', '02 / 05')
S[p.format(3)] = item('喜歡清爽、薄薄一層', 'B3 精華', '質地像水。', '03 / 05')
S[p.format(4)] = item('想加一支酸類', '杏仁酸 PHA', '晚上用，每週 2–3 晚起步，<br>白天做好防曬。', '04 / 05')
S[p.format(5)] = end('怎麼挑<br>兩支？', '留言你的保養習慣，<br>我幫你挑兩支', '傳給一直說<br>想試 PURA+ 的朋友', '05 / 05', safe=False,
                     note='<div class="note" style="margin-top:20px">實際優惠以蝦皮頁面為準</div>')

p = 'W53/W53_1231_IG圖卡_為2027選一個香氣_P{}.png'
S[p.format(1)] = c5cover('跨年夜，<br>為 2027<br>選一個香氣', '跨年夜', C['char'], C['oat'], group7)
def chak(items):
    return '<div style="flex:1;display:flex;flex-direction:column;gap:22px;margin:40px 0 100px">' + ''.join(
        f'<div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:30px"><div style="width:90px;height:90px;border-radius:50%;background:{col};flex:none"></div><div><div class="serif" style="font-size:54px">{n}</div><div class="sub" style="font-size:36px">{m}</div></div></div>'
        for _, n, m, col in items) + '</div>'
S[p.format(2)] = page(f'<div class="serif h2">七種心情</div>{chak(CHAKRA[:4])}', pg='02 / 05')
S[p.format(3)] = page(f'<div class="serif h2">選一個</div>{chak(CHAKRA[4:])}', pg='03 / 05')
S[p.format(4)] = c5text('明年每次<br>聞到它', '就會想起<br>今晚的自己。', '04 / 05', art=group7)
S[p.format(5)] = end('新年快樂', '留言你的<br>2027 關鍵字', '傳給你想<br>一起跨年的人', '05 / 05')

S['W53/W53_0101_FB方圖_新年快樂.png'] = sq(f"""<div class="serif" style="font-size:150px;line-height:1.1;margin-top:20px">2027</div>
  <div class="serif" style="font-size:80px;margin-top:10px">新年快樂</div>
  <div class="sub" style="margin-top:44px">忙得少一點，笑得多一點，<br>每天都有幾分鐘，是留給自己的。</div>""")


def main(only=None):
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        for fn, html in S.items():
            if only and only not in fn:
                continue
            out = OUT / fn
            out.parent.mkdir(parents=True, exist_ok=True)
            w = int(html.split('--w:')[1].split('px')[0]); h = int(html.split('--h:')[1].split('px')[0])
            pg = b.new_page(viewport={'width': w, 'height': h})
            pg.set_content(html, wait_until='load'); pg.wait_for_timeout(200)
            pg.screenshot(path=str(out), clip={'x': 0, 'y': 0, 'width': w, 'height': h}); pg.close()
        b.close()
    print(len(S), 'rendered')

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else None)
