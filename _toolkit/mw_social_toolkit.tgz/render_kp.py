# -*- coding: utf-8 -*-
"""v6（11/4）敏感話題貼文重出圖：不放商品名、瓶身、價格、商品連結。每組圖都有一頁 💡 精油小知識。"""
import sys
from render import page, C, SAFE, c5cover, c5text, steps, ingredient_rows, OUT
from render_dec import item, sq, SAFE_S
from playwright.sync_api import sync_playwright

S = {}

def end_s(title, ask, share, pg, safe=True):
    a = f'<div class="box" style="background:{C["sage"]};color:#fff;margin-top:48px"><div class="sub">💬 {ask}</div></div>' if ask else ''
    return page(f"""<div class="serif h1" style="margin-top:80px">{title}</div>{a}
  <div class="box" style="background:#fff;margin-top:24px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 {share}</div></div>{SAFE_S if safe else ''}""", bg=C['oat'], pg=pg)

def kpcard(head, body, pg, extra=''):
    return page(f"""<div><span class="pill" style="background:{C['sage']};color:#fff">💡 精油小知識</span></div>
  <div class="serif h1" style="font-size:84px;margin-top:44px">{head}</div>
  <div class="h3" style="margin-top:36px;line-height:1.6">{body}</div>{extra}""", bg=C['linen'], fg=C['char'], pg=pg)

# 11/17 下班後 3 分鐘（不放七脈輪）
p = 'W47/W47_1117_IG圖卡_下班後3分鐘_kp_P{}.png'
S[p.format(1)] = c5cover('下班後 3 分鐘，<br>把一天<br>慢慢收起來', '芳療師說｜聞香小知識', C['sage'], C['linen'], '')
S[p.format(2)] = page(f"""<div class="serif h2">先把燈<br>調暗一點</div>{steps(['關掉大燈，只留一盞小燈', '取一點你喜歡的按摩油在掌心，搓熱'])}""", pg='02 / 05')
S[p.format(3)] = page(f"""<div class="serif h2">再慢慢呼吸</div>{steps(['雙手放在離鼻子一個拳頭遠，慢慢吸氣、慢慢吐氣，重複 5 次', '把油輕輕推開在手臂'])}{SAFE}""", pg='03 / 05')
S[p.format(4)] = kpcard('聞香<br>有個小方法', '手掌放在離鼻子<br>一個拳頭遠，輕輕搧過來聞。<br>直接湊近，前調一下子會太強。', '04 / 05')
S[p.format(5)] = end_s('收藏，<br>今晚就試試', '你晚上最想留給自己的<br>是哪一段時間？', '傳給最近都很晚下班的朋友', '05 / 05', safe=False)

# 11/20 FB 方圖（拿掉七脈輪瓶身）
S['W47/W47_1120_FB方圖_氣味與記憶_kp.png'] = page(
    f'''<div class="serif" style="font-size:72px;line-height:1.25">聞到某個味道，<br>為什麼會突然<br>想起某個人？</div>
    <div class="box" style="background:{C['sage']};color:#fff;margin-top:56px"><div class="sub">💡 精油小知識<br>嗅覺神經和大腦中與情緒、記憶相關的區域<br>（邊緣系統）連結得很直接。</div></div>''',
    1080, 1080)

# 11/21 認識薑（不放暖身舒活、不放瓶身）
p = 'W47/W47_1121_IG圖卡_認識薑_kp_P{}.png'
S[p.format(1)] = c5cover('小雪這天，<br>認識一株<br>辛暖的植物', '認識植物｜薑', C['oat'], C['char'], '')
S[p.format(2)] = page(f"""<div class="serif h2">薑的香氣<br>在根莖</div>{ingredient_rows([('部位', '根莖'), ('萃取', '多為蒸氣蒸餾'), ('香氣', '辛暖，帶一點像檸檬的清新')])}""", pg='02 / 05')
S[p.format(3)] = c5text('像冬天廚房裡<br>剛切開的<br>一塊薑', '香氣辛暖，<br>帶一點清新。', '03 / 05')
S[p.format(4)] = kpcard('廚房的薑<br>和精油的薑', '是同一株植物，<br>但精油濃縮了大量香氣分子，<br>一定要先用植物油稀釋。', '04 / 05', extra=SAFE)
S[p.format(5)] = end_s('收藏，<br>下次切薑時<br>聞聞看', '', '傳給喜歡辛香料味道的朋友', '05 / 05', safe=False)

# 12/11 FB 方圖（拿掉 MW 濃度宣稱）
S['W50/W50_1211_FB方圖_精油不是越濃越好_kp.png'] = sq(f"""<div class="serif" style="font-size:96px;line-height:1.25;margin-top:30px">精油<br>不是越濃越好</div>
  <div class="sub" style="margin-top:44px">一小滴，就是一大把植物。</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:44px"><div class="sub">💡 精油用在皮膚前，<br>都要先用植物油稀釋</div></div>""")

# 1/5 小寒：北方森林的三種植物（不放腰背舒緩、不推背）
p = 'W01/W01_0105_IG圖卡_小寒北方森林_kp_P{}.png'
S[p.format(1)] = c5cover('小寒，<br>北方森林裡的<br>一盞暖燈', '小寒 1/5｜認識植物', C['char'], C['oat'], '')
S[p.format(2)] = page(f"""<div class="serif h2">冬天的<br>三種植物</div>{ingredient_rows([('黑雲杉', '針葉，來自北方森林'), ('杜松', '漿果，圓圓的像藍莓'), ('薑', '根莖，藏在土裡')])}""", pg='02 / 05')
S[p.format(3)] = kpcard('針葉的香氣', '黑雲杉的精油<br>來自針葉和細枝，<br>聞起來清冽，像森林。', '03 / 05')
S[p.format(4)] = kpcard('杜松的香氣<br>在漿果', '琴酒的香氣，<br>也來自杜松的漿果。', '04 / 05')
S[p.format(5)] = end_s('冷冽的森林裡，<br>有一盞暖燈', '你最喜歡哪一種<br>森林的味道？', '傳給喜歡森林味道的朋友', '05 / 05', safe=False)

# 1/19 認識安息香（不放晚安足底、不談腳冷與睡前）
p = 'W03/W03_0119_IG圖卡_認識安息香_kp_P{}.png'
S[p.format(1)] = c5cover('像香草<br>和焦糖的<br>樹脂香', '認識植物｜安息香', C['char'], C['oat'], '')
S[p.format(2)] = page(f"""<div class="serif h2">安息香<br>從哪裡來</div>{ingredient_rows([('部位', '樹幹分泌的樹脂'), ('取得', '收集樹脂後再萃取'), ('香氣', '甜甜暖暖，像香草')])}""", pg='02 / 05')
S[p.format(3)] = kpcard('為什麼<br>像香草？', '安息香的樹脂裡<br>含有少量香草醛<br>（vanillin）。', '03 / 05')
S[p.format(4)] = c5text('樹脂類的香氣', '多半揮發得慢，<br>常常是香氣<br>最後留下的那一層。', '04 / 05')
S[p.format(5)] = end_s('收藏', '你喜歡甜甜的香氣，<br>還是清爽的香氣？', '傳給喜歡香草味的朋友', '05 / 05', safe=False)

# 1/21 大寒：香氣的順序（不放一夜放鬆與瓶身、不談放鬆）
p = 'W03/W03_0121_IG圖卡_香氣的順序_kp_P{}.png'
S[p.format(1)] = c5cover('大寒：<br>花、葉、根<br>的香氣順序', '大寒 1/20｜認識香氣', C['sage'], C['linen'], '')
S[p.format(2)] = item('前段｜花', '薰衣草的花穗', '打開時最先出來，<br>乾淨、柔軟。', '02 / 05')
S[p.format(3)] = item('中段｜葉', '馬鬱蘭的葉子', '溫暖的草本味，<br>接在花香後面。', '03 / 05')
S[p.format(4)] = kpcard('後段｜根', '岩蘭草的根，蒸餾時間<br>比花葉類長很多，<br>香氣揮發得最慢。', '04 / 05')
S[p.format(5)] = end_s('一年也像這樣，<br>從開花<br>走到扎根', '這一年，<br>你最想謝謝自己什麼？', '傳給這一年<br>辛苦了的朋友', '05 / 05', safe=False)

# 對照用：kp 版取代的舊圖
REPLACES = {
    '2026-11-17': 'W47/W47_1117_IG圖卡_下班後3分鐘_P', '2026-11-20': 'W47/W47_1120_FB方圖_為什麼聞香氣會放鬆',
    '2026-11-21': 'W47/W47_1121_IG圖卡_暖身舒活辛暖_P', '2026-12-11': 'W50/W50_1211_FB方圖_精油不是越濃越好.png',
    '2027-01-05': 'W01/W01_0105_IG圖卡_小寒北方森林_P', '2027-01-19': 'W03/W03_0119_IG圖卡_冷天的腳底_P',
    '2027-01-21': 'W03/W03_0121_IG圖卡_大寒夜10分鐘_P',
}

def main(only=None):
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        for fn, html in S.items():
            if only and only not in fn:
                continue
            out = OUT / fn
            out.parent.mkdir(parents=True, exist_ok=True)
            w = int(html.split('--w:')[1].split('px')[0]); h = int(html.split('--h:')[1].split('px')[0])
            pg = b.new_page(viewport={'width': w, 'height': h})
            pg.set_content(html, wait_until='load')
            pg.wait_for_timeout(250)
            pg.screenshot(path=str(out), clip={'x': 0, 'y': 0, 'width': w, 'height': h})
            pg.close()
        b.close()
    print(len(S), 'rendered')

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else None)
