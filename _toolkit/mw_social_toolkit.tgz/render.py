# -*- coding: utf-8 -*-
"""MW 11 月 W45–W48 社群圖檔產生器（HTML → Playwright PNG）"""
import os, sys, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).parent
CUT = (ROOT / 'cut').resolve()
OUT = ROOT / 'out'
OUT.mkdir(exist_ok=True)

C = dict(linen='#F5F3F0', oat='#E3D5C3', sage='#335C4F', char='#3A3A36', amber='#C4703E',
         damber='#A85A2C', frost='#8DA9B5', sagel='#8A9A7B', white='#FFFFFF')
SIX = [  # 現行品名｜識別色｜建議時段（⚠️ 依品名語意排列，Morris 確認）
    ('一夜放鬆', '#8C7BA8', '睡前', '🌙'),
    ('胸頸自信', '#D69AA6', '出門前', '☀️'),
    ('美體勻潤', '#D9B44A', '洗澡後全身', '🛁'),
    ('清新舒緩', '#6F9BB8', '早上・醒神', '☀️'),
    ('暖身舒活', '#D98A4E', '冷天・泡澡後', '🛁'),
    ('淨立舒緩', '#7FA37A', '久站下班後', '🌙'),
]
CHAKRA = [  # NO｜品名｜情緒方向｜色
    (1, '根源安定', '想要穩定', '#9E3B2E'), (2, '流動創造', '想要溫暖', '#A0584C'),
    (3, '自信光能', '想要自信', '#C99A3B'), (4, '愛與平衡', '想要柔軟', '#4F7A5C'),
    (5, '表達清晰', '想要表達', '#4B4F8C'), (6, '直覺洞察', '想要專注', '#4A4E52'),
    (7, '靈性啟光', '想要沉靜', '#6A4C7A'),
]

CSS = f"""
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:'Noto Sans CJK TC','Noto Sans TC',sans-serif;color:{C['char']};}}
.f{{position:relative;overflow:hidden;width:var(--w);height:var(--h);padding:84px 80px;display:flex;flex-direction:column}}
.serif{{font-family:'Noto Serif CJK TC','Noto Serif TC',serif;font-weight:700}}
.pill{{display:inline-block;border-radius:999px;padding:12px 30px;font-size:30px;font-weight:700;letter-spacing:2px}}
.brand{{position:absolute;left:80px;bottom:52px;font-size:26px;letter-spacing:3px;opacity:.8}}
.pg{{position:absolute;right:80px;bottom:52px;font-size:26px;letter-spacing:2px;opacity:.7}}
.h1{{font-size:104px;line-height:1.22;letter-spacing:2px}}
.h2{{font-size:78px;line-height:1.28}}
.h3{{font-size:54px;line-height:1.35}}
.sub{{font-size:42px;line-height:1.6}}
.body{{font-size:40px;line-height:1.75}}
.small{{font-size:32px;line-height:1.6}}
.box{{border-radius:28px;padding:36px 40px}}
.row{{display:flex;gap:24px;align-items:center}}
.note{{font-size:28px;line-height:1.6;opacity:.85}}
.num{{font-family:'Noto Serif CJK TC',serif;font-weight:700;font-size:150px;line-height:1}}
img.prod{{filter:drop-shadow(0 24px 30px rgba(58,58,54,.28))}}
"""

def page(inner, w=1080, h=1350, bg=C['linen'], fg=C['char'], pg=None, brand=True, extra=''):
    b = f'<div class="brand">MW精油工坊｜IFA 芳療師監製</div>' if brand else ''
    p = f'<div class="pg">{pg}</div>' if pg else ''
    return (f'<!doctype html><html><head><meta charset="utf-8"><style>{CSS}{extra}</style></head>'
            f'<body><div class="f" style="--w:{w}px;--h:{h}px;background:{bg};color:{fg}">{inner}{b}{p}</div></body></html>')

import base64, functools
@functools.lru_cache(None)
def _b64(name):
    return base64.b64encode((CUT / name).read_bytes()).decode()
def img(name, style=''):
    return f'<img class="prod" src="data:image/png;base64,{_b64(name)}" style="{style}">'

SAFE = (f'<div class="box" style="background:{C["oat"]};margin-top:auto;margin-bottom:70px">'
        '<div class="small"><b>使用小提醒</b><br>✔ 第一次使用先在手臂內側小面積試用<br>'
        '✔ 避開眼周與黏膜<br>✔ 孕期、哺乳期或特殊體質，請先諮詢醫師</div></div>')

def cover_reels(title, kicker, bg, fg, art=''):
    return page(f'''<div style="margin-top:180px"><span class="pill" style="background:{fg};color:{bg}">{kicker}</span></div>
      <div class="serif" style="font-size:96px;line-height:1.25;margin-top:48px">{title}</div>
      <div style="position:absolute;left:0;right:0;bottom:300px;display:flex;justify-content:center;gap:10px;align-items:flex-end">{art}</div>''',
      1080, 1920, bg, fg)

S = {}  # filename -> html

# ───────── W45 ─────────
S['W45/W45_1103_Reels封面_立冬換季清單.png'] = cover_reels(
    '立冬前，<br>我的按摩油<br>換季清單', 'IG Reels｜立冬 11/7', C['frost'], C['white'],
    img('breath250.png', 'height:760px'))

# 11/05 七頁選香指南
p = 'W45/W45_1105_IG圖卡_六種香氣怎麼選_P{}.png'
S[p.format(1)] = page(f'''<div><span class="pill" style="background:{C['sage']};color:#fff">芳療師說｜冬季選香</span></div>
  <div class="serif h1" style="margin-top:60px">六種香氣<br>怎麼選？</div>
  <div class="sub" style="margin-top:28px">不看功效，<br>照「你想要的心情」來挑。</div>
  <div style="position:absolute;right:40px;bottom:120px">{img('breath250.png','height:720px')}</div>''',
  bg=C['linen'], pg='01 / 07')
S[p.format(2)] = page(f'''<div class="serif h2">我幫客人挑油時，<br>只問一個問題</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:40px">
   <div class="serif" style="font-size:46px;line-height:1.4">你通常在「什麼時間」用？<br>想要「什麼感覺」？</div></div>
  <div style="flex:1;display:flex;flex-direction:column;gap:24px;margin:36px 0 100px"><div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:30px"><div style="font-size:84px">☀️</div><div><div class="h3 serif">早上出門前</div><div class="sub">柑橘、草本調，香氣明亮</div></div></div><div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:30px"><div style="font-size:84px">🌙</div><div><div class="h3 serif">睡前</div><div class="sub">花香、木質調，香氣沉穩</div></div></div><div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:30px"><div style="font-size:84px">🛁</div><div><div class="h3 serif">泡澡後全身</div><div class="sub">選你聞了會想深呼吸的那一款</div></div></div></div>''',
  pg='02 / 07')
def six_rows(items):
    r = '<div style="flex:1;display:flex;flex-direction:column;gap:36px;margin-bottom:90px">'
    for n, col, t, e in items:
        r += (f'<div style="flex:1;background:#fff;border-radius:32px;padding:50px 56px;display:flex;align-items:center;gap:44px">'
              f'<div style="width:150px;height:150px;border-radius:50%;background:{col};flex:none"></div>'
              f'<div><div class="serif" style="font-size:76px;line-height:1.2">{n}</div>'
              f'<div class="sub" style="margin-top:14px">{e} 建議時段：{t}</div></div></div>')
    return r + '</div>'
S[p.format(3)] = page(f'''<div class="serif h2" style="margin-bottom:48px">經典按摩油六款<br><span style="font-size:40px">250mL・植物油基底</span></div>{six_rows(SIX[:2])}''', pg='03 / 07')
S[p.format(4)] = page(f'''<div class="serif h2" style="margin-bottom:48px">依時段挑香氣</div>{six_rows(SIX[2:4])}''', pg='04 / 07')
S[p.format(5)] = page(f'''<div class="serif h2" style="margin-bottom:48px">你是早上派<br>還是睡前派？</div>{six_rows(SIX[4:])}''', pg='05 / 07')
S[p.format(6)] = page(f'''<div class="serif h2">第一次用、<br>不知道從哪開始？</div>
  <div class="sub" style="margin-top:28px">從「入門兩瓶組合」開始就好</div>
  <div class="row" style="margin-top:60px;gap:30px;flex:1;align-items:stretch;margin-bottom:40px">
   <div class="box" style="flex:1;background:#fff;text-align:center;display:flex;flex-direction:column;justify-content:center"><div style="font-size:110px">☀️</div><div class="h3 serif">早上一瓶</div><div class="small">選你喜歡的明亮香氣</div></div>
   <div class="box" style="flex:1;background:#fff;text-align:center;display:flex;flex-direction:column;justify-content:center"><div style="font-size:110px">🌙</div><div class="h3 serif">晚上一瓶</div><div class="small">選你喜歡的沉穩香氣</div></div></div>
  {SAFE}''', pg='06 / 07')
S[p.format(7)] = page(f'''<div class="serif h1" style="margin-top:120px">收藏這篇，<br>1111 選油<br>不再猶豫</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:70px"><div class="sub">💬 留言告訴我：<br>你是「早上派」還是「睡前派」？</div></div>
  <div class="small" style="margin-top:40px">🔗 商品連結在主頁｜限動也有連結貼紙</div>''', bg=C['oat'], pg='07 / 07')

# 11/06 FB 方圖
steps = ['配方｜IFA 芳療師設計', '原料進廠｜檢驗文件、留樣', '調配充填｜批次製造紀錄', '出貨前｜外觀・氣味・標示確認', 'PIF｜產品資訊檔案彙整']
S['W45/W45_1106_FB方圖_一瓶按摩油經過幾道關.png'] = page(
    f'''<div class="serif" style="font-size:66px;line-height:1.25">一瓶按摩油，<br>要經過幾道關？</div>
    <div class="sub" style="margin:16px 0 44px">在我們自己的 ISO 22716 化粧品 GMP 工廠</div>''' +
    ''.join(f'<div class="row" style="margin-bottom:30px"><div class="serif" style="width:92px;height:92px;flex:none;border-radius:50%;background:{C["sage"]};color:#fff;font-size:48px;display:flex;align-items:center;justify-content:center">{i+1}</div><div class="h3" style="font-size:46px">{s}</div></div>' for i, s in enumerate(steps)),
    1080, 1080, C['linen'])

# 11/08 1111 倒數 3 天
S['W45/W45_1108_單圖_1111倒數3天.png'] = page(
    f'''<div><span class="pill" style="background:#fff;color:{C['damber']}">檔期導購</span></div>
    <div class="serif" style="font-size:200px;line-height:1;margin-top:70px">11.11</div>
    <div class="serif" style="font-size:88px;margin-top:20px">倒數 3 天</div>
    <div class="box" style="background:{C['amber']};margin-top:60px">
     <div class="body" style="font-size:34px;font-weight:700">🌿 經典按摩油六款 250mL<br>🧴 PURA+ 任選 2 入 <b style="font-size:48px">699</b><br>⏰ 11/11 整天都有限時特賣場次</div></div>
    <div class="sub" style="margin-top:44px">先關注賣場＋加入購物車</div>
    <div class="note" style="margin-top:auto;margin-bottom:40px">PURA+ 組合活動 11/2–12/31｜實際優惠以蝦皮頁面為準</div>''',
    bg=C['sage'], fg=C['linen'])

# ───────── W46 ─────────
p = 'W46/W46_1109_IG圖卡_1111囤貨清單_P{}.png'
S[p.format(1)] = page(f'''<div><span class="pill" style="background:#fff;color:{C['damber']}">1111 囤貨清單</span></div>
  <div class="serif h1" style="margin-top:60px">芳療師<br>自己會買的<br>5 瓶</div>
  <div class="sub" style="margin-top:30px">天天用的買大瓶，<br>臉部保養挑重點。</div>
  <div style="position:absolute;right:50px;bottom:110px">{img('breath250.png','height:640px')}</div>''',
  bg=C['sage'], fg=C['linen'], pg='01 / 07')
S[p.format(2)] = page(f'''<div class="pill" style="background:{C['damber']};color:#fff;align-self:flex-start">身體｜×2</div>
  <div class="serif h2" style="margin-top:40px">經典按摩油六款<br>250mL</div>
  <div class="body" style="margin-top:30px">早晚各一種香氣，<br>冬天洗完澡全身用，<br>大瓶比較划算。</div>
  <div style="position:absolute;right:70px;bottom:120px">{img('breath250.png','height:620px')}</div>''', pg='02 / 07')
S[p.format(3)] = page(f'''<div class="pill" style="background:{C['damber']};color:#fff;align-self:flex-start">睡前｜×1</div>
  <div class="serif h2" style="margin-top:40px">一夜放鬆<br>250mL</div>
  <div class="body" style="margin-top:30px">睡前肩頸、腳底按一按，<br>讓香氣陪你慢下來。</div>
  <div style="flex:1;display:flex;flex-direction:column;gap:24px;margin:50px 0 100px"><div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:30px"><div class="serif" style="font-size:72px;color:#C4703E;width:70px">1</div><div class="sub">關掉大燈，只留一盞小燈</div></div><div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:30px"><div class="serif" style="font-size:72px;color:#C4703E;width:70px">2</div><div class="sub">取適量，掌心搓熱、深呼吸 5 次</div></div><div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:30px"><div class="serif" style="font-size:72px;color:#C4703E;width:70px">3</div><div class="sub">腳底 → 小腿 → 肩頸，輕推約 3 分鐘</div></div></div>''', pg='03 / 07')
S[p.format(4)] = page(f'''<div class="pill" style="background:{C['damber']};color:#fff;align-self:flex-start">臉部｜任選 2 入</div>
  <div class="serif h2" style="margin-top:40px">PURA+ 保養三支</div>
  <div style="flex:1;display:flex;flex-direction:column;gap:24px;margin:40px 0 100px"><div class="box" style="flex:1;background:#fff;display:flex;flex-direction:column;justify-content:center"><div class="h3 serif">角鯊烷</div><div class="small">乾燥季節的保濕好朋友</div></div>
  <div class="box" style="flex:1;background:#fff;display:flex;flex-direction:column;justify-content:center"><div class="h3 serif">杏仁酸 PHA</div><div class="small">讓肌膚觸感更細緻（敏感肌從隔天一次開始，白天加強防曬）</div></div>
  <div class="box" style="flex:1;background:#fff;display:flex;flex-direction:column;justify-content:center"><div class="h3 serif">B3 精華</div><div class="small">日常保濕、讓膚色看起來更有光澤</div></div></div>''', pg='04 / 07')
S[p.format(5)] = page(f'''<div class="serif h2">怎麼配最順手？</div>
  <div class="body" style="margin-top:40px">☀️ 早上｜清新香氣全身按摩<br>🌙 晚上｜一夜放鬆，肩頸＋腳底<br>✨ 臉部｜化妝水 → B3 → 角鯊烷<br>　　　（杏仁酸 PHA 晚上隔天用，白天加強防曬）</div>{SAFE}''', pg='05 / 07')
S[p.format(6)] = page(f'''<div class="serif h2">1111 價格看這裡</div>
  <div class="box" style="background:{C['damber']};margin-top:50px"><div class="sub">PURA+ 任選 2 入</div><div class="serif" style="font-size:140px;line-height:1.1">699</div><div class="small">單買 396｜活動 11/2–12/31</div></div>
  <div class="box" style="background:rgba(255,255,255,.18);margin-top:30px"><div class="sub">按摩油限時價</div><div class="body">11/11 整天都有限時特賣場次<br>時段看限動</div></div>
  <div class="note" style="margin-top:auto;margin-bottom:40px">實際優惠以蝦皮頁面為準｜限時價數量有限，賣完就恢復原價</div>''',
  bg=C['sage'], fg=C['linen'], pg='06 / 07')
S[p.format(7)] = page(f'''<div class="serif h1" style="margin-top:120px">收藏起來<br>當購物清單</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:70px"><div class="sub">💬 你今年 1111<br>最想補哪一瓶？</div></div>
  <div class="small" style="margin-top:40px">🔗 點主頁連結｜限動也有連結貼紙</div>''', bg=C['oat'], pg='07 / 07')

S['W46/W46_1110_Reels封面_出貨前一晚.png'] = cover_reels('1111<br>出貨前一晚，<br>工廠在忙什麼？', 'IG Reels｜工廠透明', C['sage'], '#fff', '<div style="border:6px solid #fff;border-radius:50%;width:560px;height:560px;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff"><div class="serif" style="font-size:88px">ISO 22716</div><div style="font-size:40px;letter-spacing:6px;margin-top:10px">化粧品 GMP 工廠</div></div>')

S['W46/W46_1111_單圖_1111開跑.png'] = page(
    f'''<div class="serif" style="font-size:200px;line-height:1;margin-top:90px">11.11</div>
    <div class="serif" style="font-size:96px;margin-top:20px">今天開跑</div>
    <div class="box" style="background:{C['damber']};margin-top:70px"><div class="h3 serif">⏰ 限時特賣</div><div class="sub">整天都有限時特賣場次<br>時段、品項看限動</div></div>
    <div class="box" style="background:rgba(255,255,255,.18);margin-top:26px"><div class="sub">🧴 PURA+ 任選 2 入 <b style="font-size:52px">699</b>｜整天都有</div></div>
    <div class="note" style="margin-top:auto;margin-bottom:40px">實際優惠以蝦皮頁面為準｜限時價數量有限，賣完就恢復原價</div>''',
    bg=C['sage'], fg=C['linen'])
for t, line, sub in [('早上預告', '早上', '今天整天<br>都有限時特賣場次'), ('倒數A', '倒數', '下一場限時特賣<br>10 分鐘後開始'), ('倒數B', '倒數', '下一場限時特賣<br>10 分鐘後開始')]:
    S[f'W46/W46_1111_限動_{t}.png'] = page(
        f'''<div style="margin-top:300px"><span class="pill" style="background:#fff;color:{C['damber']}">1111｜{line}</span></div>
        <div class="serif" style="font-size:110px;line-height:1.25;margin-top:60px">{sub}</div>
        <div class="sub" style="margin-top:60px">👆 點連結貼紙進賣場</div>
        <div style="margin-top:auto;margin-bottom:330px" class="note">（連結貼紙放這裡）<br>實際優惠以蝦皮頁面為準</div>''',
        1080, 1920, C['sage'], C['linen'], brand=False)

S['W46/W46_1113_FB方圖_保存3原則.png'] = page(
    f'''<div class="serif" style="font-size:66px;line-height:1.25">囤了油之後：<br>讓香氣留久一點</div>
    <div class="row" style="margin-top:50px;gap:24px">''' +
    ''.join(f'<div class="box" style="flex:1;background:#fff;text-align:center;padding:60px 20px;min-height:430px;display:flex;flex-direction:column;justify-content:center"><div style="font-size:96px">{e}</div><div class="h3 serif" style="margin-top:10px">{a}</div><div class="small">{b}</div></div>'
            for e, a, b in [('🌑', '避光', '放抽屜、櫃子'), ('🌡️', '避熱', '遠離暖風機'), ('🔒', '少碰空氣', '用完鎖緊瓶蓋')]) +
    f'''</div><div class="sub" style="margin-top:50px;font-size:36px">出現油耗味、顏色明顯變深、質地變黏，<br>就不建議再用在皮膚上。</div>''',
    1080, 1080)

# ───────── W47 ─────────
group7 = ''.join(img(f'chakra{n}.png', 'height:330px;margin:0 -12px') for n in range(1, 8))
S['W47/W47_1117_Reels封面_睡前3分鐘.png'] = cover_reels('睡前 3 分鐘：<br>用香氣把<br>一天收起來', 'IG Reels｜小雪 11/22', C['sage'], C['linen'], img('chakra4.png', 'height:780px'))
p = 'W47/W47_1119_IG圖卡_七脈輪香氣地圖_P{}.png'
S[p.format(1)] = page(f'''<div><span class="pill" style="background:{C['sage']};color:#fff">芳療師說｜七脈輪</span></div>
  <div class="serif h1" style="margin-top:56px;font-size:78px">七脈輪不是玄學，<br>是一張<br>香氣選擇地圖</div>
  <div style="position:absolute;left:0;right:0;bottom:120px;display:flex;justify-content:center;align-items:flex-end">{group7}</div>''', pg='01 / 07')
def chakra_cards(items):
    r = '<div style="flex:1;display:flex;flex-direction:column;gap:30px;margin-bottom:90px">'
    for n, name, mood, col in items:
        r += (f'<div style="flex:1;background:#fff;border-radius:32px;padding:20px 44px;display:flex;align-items:center;gap:40px">'
              f'{img(f"chakra{n}.png", "height:250px")}'
              f'<div><div class="small" style="color:{col};font-weight:700;letter-spacing:3px">{n:02d}｜CHAKRA</div>'
              f'<div class="serif" style="font-size:66px;line-height:1.25">{name}</div><div class="sub">{mood}的時候</div></div></div>')
    return r + '</div>'
S[p.format(2)] = page(f'<div class="serif h3" style="margin-bottom:30px">7 種情緒方向 ①</div>{chakra_cards(CHAKRA[:3])}', pg='02 / 07')
S[p.format(3)] = page(f'<div class="serif h3" style="margin-bottom:30px">7 種情緒方向 ②</div>{chakra_cards(CHAKRA[3:5])}', pg='03 / 07')
S[p.format(4)] = page(f'<div class="serif h3" style="margin-bottom:30px">7 種情緒方向 ③</div>{chakra_cards(CHAKRA[5:])}', pg='04 / 07')
S[p.format(5)] = page(f'''<div class="serif h2">入門怎麼挑？</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:60px"><div class="h3 serif">先選一款<br>「你聞了會想多聞一下」的</div></div>
  <div class="sub" style="margin-top:40px">不要選「你覺得應該需要」的。<br>香氣喜好本來就因人而異。</div>{SAFE}''', pg='05 / 07')
S[p.format(6)] = page(f'''<div class="serif h2">100mL 還是 250mL？</div>
  <div class="row" style="margin-top:50px;gap:30px;align-items:stretch">
   <div class="box" style="flex:1;background:#fff;text-align:center;padding:56px 30px"><div class="h3 serif">100mL</div><div class="small" style="margin-top:16px">第一次試香<br>送禮、交換禮物<br>放包包、辦公室</div></div>
   <div class="box" style="flex:1;background:#fff;text-align:center;padding:56px 30px"><div class="h3 serif">250mL</div><div class="small" style="margin-top:16px">已經有固定喜歡的香氣<br>每天全身用<br>全家一起用</div></div></div>
  <div style="margin-top:auto;margin-bottom:60px;display:flex;justify-content:center">{img('chakra3.png','height:520px')}</div>''', pg='06 / 07')
S[p.format(7)] = page(f'''<div class="serif h1" style="margin-top:120px">收藏<br>這張地圖</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:70px"><div class="sub">💬 留言你現在最想要的心情，<br>我幫你配一款</div></div>
  <div class="small" style="margin-top:40px">🔗 商品連結在主頁｜限動也有連結貼紙</div>''', bg=C['oat'], pg='07 / 07')
S['W47/W47_1120_FB方圖_為什麼聞香氣會放鬆.png'] = page(
    f'''<div class="serif" style="font-size:64px;line-height:1.25">聞到某個味道，<br>為什麼會突然<br>想起某個人？</div>
    <div class="sub" style="margin-top:24px">嗅覺與大腦中負責情緒、記憶的區域<br>連結得很直接。</div>
    <div style="position:absolute;left:0;right:0;bottom:100px;display:flex;justify-content:center;align-items:flex-end">{''.join(img(f"chakra{n}.png", "height:300px;margin:0 -10px") for n in range(1,8))}</div>''',
    1080, 1080)

# ───────── W48 ─────────
S['W48/W48_1124_Reels封面_客人最常說的一句話.png'] = cover_reels('9 年來，<br>客人最常跟我們<br>說的一句話', 'IG Reels｜感恩節', C['linen'], C['char'], '<div class="serif" style="font-size:620px;line-height:.8;color:#5E6E52;opacity:.85">“</div>')
p = 'W48/W48_1126_IG圖卡_回購Top5_P{}.png'
S[p.format(1)] = page(f'''<div><span class="pill" style="background:{C['sage']};color:#fff">互動｜感恩節</span></div>
  <div class="serif h1" style="margin-top:60px">2026<br>回購 Top 5</div>
  <div class="sub" style="margin-top:30px">大家用完又回來的油</div>
  <div style="position:absolute;left:0;right:0;bottom:120px;display:flex;justify-content:center;align-items:flex-end">{group7}</div>''', pg='01 / 07')
for i in range(5):
    S[p.format(i + 2)] = page(f'''<div class="num" style="color:{C['sage']}">{5 - i}</div>
      <div class="serif h2" style="margin-top:20px">（填入商品名）</div>
      <div class="small">依蝦皮後台回購數據</div>
      <div class="box" style="background:#fff;margin-top:50px;min-height:420px"><div class="small" style="opacity:.6">（貼上評價收集 DB 的真實評價截圖，<br>遮蔽帳號、一字不改；含功效字眼的評價整則不用）</div></div>''',
      pg=f'0{i + 2} / 07')
S[p.format(7)] = page(f'''<div class="serif h1" style="margin-top:120px">謝謝你<br>一直回來</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:70px"><div class="sub">💬 留言你的「家人最愛」<br>是哪一瓶</div></div>
  <div class="small" style="margin-top:40px">🔗 商品連結在主頁｜限動也有連結貼紙</div>''', bg=C['oat'], pg='07 / 07')
S['W48/W48_1127_FB方圖_謝謝你9年.png'] = page(
    f'''<div class="serif" style="font-size:72px;line-height:1.3;margin-top:30px">謝謝你，<br>讓一間小工廠<br>走了 9 年</div>
    <div class="body" style="margin-top:44px">ISO 22716 化粧品 GMP 工廠<br>IFA 芳療師把關配方<br>賣場評價 5.0｜蝦皮優選賣家</div>
    <div class="serif" style="position:absolute;right:40px;bottom:-60px;font-size:560px;line-height:1;opacity:.18">9</div>''',
    1080, 1080, C['sage'], '#fff')

# ───────── 11/14 蝦皮分潤計畫招募（加開）─────────
S['W46/W46_1114_單圖_分享MW賺推廣金.png'] = page(f'''<div><span class="pill" style="background:{C['sage']};color:#fff">蝦皮分潤計畫｜邀請你</span></div>
  <div class="serif h1" style="margin-top:40px;font-size:84px">喜歡 MW 的油，<br>也想分享給朋友嗎？</div>
  <div class="box" style="background:#fff;margin-top:50px">
    <div class="sub" style="font-size:40px"><b>推廣金</b> ＝ 蝦皮回饋率 ＋ 賣家分潤率</div>
    <div class="body" style="margin-top:14px">經典按摩油六款 250mL、<br>七脈輪按摩油 100mL<br>目前賣家分潤 <b style="font-size:56px;color:{C['sage']}">15%</b></div></div>
  <div class="box" style="background:{C['oat']};margin-top:28px"><div class="body">① 蝦皮 App 我的 → 蝦皮分潤計畫<br>② 填資料送審（約 3–5 個工作天）<br>③ 在商品頁按分享 → 複製連結</div></div>
  <div class="note" style="margin-top:auto;margin-bottom:110px">免費加入｜推廣金依蝦皮規則與完成訂單計算<br>以蝦皮官方說明為準</div>''', pg=None)
S['W46/W46_1114_限動_分享MW賺推廣金.png'] = page(f'''<div style="margin-top:260px"><span class="pill" style="background:#fff;color:{C['sage']}">蝦皮分潤計畫</span></div>
  <div class="serif" style="font-size:104px;line-height:1.25;margin-top:50px">分享你用過的<br>MW 按摩油，<br>領推廣金</div>
  <div class="sub" style="margin-top:50px">經典六款 250mL、七脈輪 100mL<br>賣家分潤 15%<br>留言 指南 兩個字<br>拿分享小指南</div>
  <div class="note" style="margin-top:auto;margin-bottom:330px">（連結貼紙：蝦皮分潤計畫頁）<br>以蝦皮官方說明為準</div>''', 1080, 1920, C['sage'], '#fff', brand=False)

# ═════════ v3（11/3）國際成長技巧套用：轉傳CTA／Reels A/B 鉤子／週六 Reels ═════════
def p7(title, ask, share, bg=None, fg=None):
    return page(f"""<div class="serif h1" style="margin-top:100px">{title}</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:56px"><div class="sub">💬 {ask}</div></div>
  <div class="box" style="background:#fff;margin-top:28px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 {share}</div></div>
  <div class="small" style="margin-top:36px">🔗 商品連結在主頁｜限動也有連結貼紙</div>""", bg=C['oat'], pg='07 / 07')

S['W45/W45_1105_IG圖卡_六種香氣怎麼選_P7.png'] = p7('收藏這篇，<br>1111 選油<br>不再猶豫', '留言告訴我：<br>你是「早上派」還是「睡前派」？', '傳給每次都問你<br>「用什麼油」的那位朋友')
S['W46/W46_1109_IG圖卡_1111囤貨清單_P7.png'] = p7('收藏起來<br>當購物清單', '你今年 1111<br>最想補哪一瓶？', '傳給一起湊單的朋友，<br>清單直接對照')
S['W47/W47_1119_IG圖卡_七脈輪香氣地圖_P7.png'] = p7('收藏<br>這張地圖', '留言你現在最想要的心情，<br>我幫你配一款', '傳給最近很需要<br>「慢下來」的朋友')
S['W48/W48_1126_IG圖卡_回購Top5_P7.png'] = p7('謝謝你<br>一直回來', '留言你的「家人最愛」<br>是哪一瓶', '傳給當初<br>推薦你用 MW 的那個人')

ISO = '<div style="border:6px solid #fff;border-radius:50%;width:560px;height:560px;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff"><div class="serif" style="font-size:88px">ISO 22716</div><div style="font-size:40px;letter-spacing:6px;margin-top:10px">化粧品 GMP 工廠</div></div>'
QUOTE = '<div class="serif" style="font-size:620px;line-height:.8;color:#5E6E52;opacity:.85">“</div>'
# Reels B 版封面（試驗性 Reels 測鉤子；A 版＝原封面）
S['W46/W46_1110_Reels封面_出貨前一晚_B.png'] = cover_reels('你下單後，<br>這瓶油經過<br>哪幾雙手？', 'IG Reels｜工廠透明', C['sage'], '#fff', ISO)
S['W47/W47_1117_Reels封面_睡前3分鐘_B.png'] = cover_reels('芳療師自己<br>睡前會做的<br>3 分鐘', 'IG Reels｜小雪 11/22', C['sage'], C['linen'], img('chakra4.png', 'height:780px'))
S['W48/W48_1124_Reels封面_客人最常說的一句話_B.png'] = cover_reels('這句話，<br>我們聽了<br>9 年', 'IG Reels｜感恩節', C['linen'], C['char'], QUOTE)
# 新增：週六 Reels（A/B）
S['W46/W46_1115_Reels封面_按摩油倒太多了.png'] = cover_reels('多數人<br>倒按摩油，<br>都倒太多了', 'IG Reels｜芳療師說', C['linen'], C['char'], img('breath250.png', 'height:760px'))
S['W46/W46_1115_Reels封面_按摩油倒太多了_B.png'] = cover_reels('按摩油<br>取多少<br>才剛好？', 'IG Reels｜芳療師說', C['linen'], C['char'], img('breath250.png', 'height:760px'))
S['W47/W47_1121_Reels封面_六種香氣30秒.png'] = cover_reels('同樣 250mL，<br>六種香氣<br>怎麼選？', 'IG Reels｜小雪 11/22', C['frost'], C['white'], img('breath250.png', 'height:760px'))
S['W47/W47_1121_Reels封面_六種香氣30秒_B.png'] = cover_reels('你是早上派，<br>還是<br>睡前派？', 'IG Reels｜小雪 11/22', C['frost'], C['white'], img('breath250.png', 'height:760px'))

# ═════════ v4（11/3）品牌聲音 v1.2：感性 × 原料說明、少提工廠；圖上字不用「」 ═════════
for k in ['W45/W45_1106_FB方圖_一瓶按摩油經過幾道關.png', 'W46/W46_1115_Reels封面_按摩油倒太多了.png', 'W46/W46_1115_Reels封面_按摩油倒太多了_B.png',
          'W47/W47_1121_Reels封面_六種香氣30秒.png', 'W47/W47_1121_Reels封面_六種香氣30秒_B.png']:
    S.pop(k, None)
SIX4 = [  # 品名｜識別色｜植物部位（商品頁重建包確認之主香）｜香氣
    ('清新舒緩', '#6F9BB8', '尤加利・迷迭香・綠花白千層｜枝葉', '像冬天早上推開窗的空氣'),
    ('淨立舒緩', '#7FA37A', '絲柏枝葉・杜松漿果・牛膝草', '雨後森林步道的木質感'),
    ('美體勻潤', '#D9B44A', '甜茴香與蒔蘿的種子・檸檬果皮', '帶一點甜的明亮柑橘'),
    ('一夜放鬆', '#8C7BA8', '薰衣草花穗・馬鬱蘭・岩蘭草根', '花香慢慢沉成木質'),
    ('胸頸自信', '#D69AA6', '玫瑰天竺葵・依蘭的花・快樂鼠尾草', '柔軟的花香'),
    ('暖身舒活', '#D98A4E', '薑的根莖・藍膠尤加利・薄荷', '先辛暖，再留一點清涼'),
]
def six4(items):
    r = '<div style="flex:1;display:flex;flex-direction:column;gap:36px;margin-bottom:90px">'
    for n, col, parts, scent in items:
        r += (f'<div style="flex:1;background:#fff;border-radius:32px;padding:44px 50px;display:flex;align-items:center;gap:40px">'
              f'<div style="width:130px;height:130px;border-radius:50%;background:{col};flex:none"></div>'
              f'<div><div class="serif" style="font-size:70px;line-height:1.2">{n}</div>'
              f'<div class="small" style="margin-top:10px;font-weight:700">{parts}</div>'
              f'<div class="sub" style="margin-top:6px;font-size:38px">{scent}</div></div></div>')
    return r + '</div>'
def p7q(title, ask, share):
    return page(f"""<div class="serif h1" style="margin-top:100px">{title}</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:56px"><div class="sub">💬 {ask}</div></div>
  <div class="box" style="background:#fff;margin-top:28px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 {share}</div></div>
  <div class="small" style="margin-top:36px">🔗 商品連結在主頁｜限動也有連結貼紙</div>""", bg=C['oat'], pg='07 / 07')
def ingredient_rows(rows):
    return '<div style="flex:1;display:flex;flex-direction:column;gap:24px;margin:44px 0 100px">' + ''.join(
        f'<div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:30px"><div class="serif" style="font-size:60px;color:{C["sage"]};min-width:220px">{a}</div><div class="sub">{b}</div></div>' for a, b in rows) + '</div>'

# 11/05 認識六種植物
p = 'W45/W45_1105_IG圖卡_六種香氣怎麼選_P{}.png'
S[p.format(1)] = page(f"""<div><span class="pill" style="background:{C['sage']};color:#fff">芳療師說｜認識植物</span></div>
  <div class="serif h1" style="margin-top:60px;font-size:92px">打開瓶蓋之前，<br>先認識<br>六種植物</div>
  <div class="sub" style="margin-top:28px">香氣，來自植物的哪裡？</div>
  <div style="position:absolute;right:40px;bottom:110px">{img('breath250.png','height:640px')}</div>""", pg='01 / 07')
S[p.format(2)] = page(f"""<div class="serif h2">我挑油時，<br>會先請你聞</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:40px"><div class="serif" style="font-size:44px;line-height:1.45">知道香氣從哪裡來，<br>就知道你想要哪一種時刻</div></div>
  {ingredient_rows([('花・花穗', '柔軟的花香'), ('枝葉・根', '清透的綠意、沉穩的木質'), ('果皮・種子', '明亮、帶一點甜')])}""", pg='02 / 07')
S[p.format(3)] = page(f'<div class="serif h2" style="margin-bottom:44px">經典按摩油六款<br><span style="font-size:40px">250mL・植物油基底</span></div>{six4(SIX4[:2])}', pg='03 / 07')
S[p.format(4)] = page(f'<div class="serif h2" style="margin-bottom:44px">香氣來自<br>植物的哪裡</div>{six4(SIX4[2:4])}', pg='04 / 07')
S[p.format(5)] = page(f'<div class="serif h2" style="margin-bottom:44px">花香、木質，<br>還是辛暖？</div>{six4(SIX4[4:])}', pg='05 / 07')
S[p.format(6)] = page(f"""<div class="serif h2">不知道從哪一瓶開始？</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:50px"><div class="h3 serif">挑那一款，<br>聞了會想多停留一下的</div></div>
  <div class="sub" style="margin-top:40px">香氣喜好本來就因人而異。<br>六款都已稀釋好，直接使用就可以。</div>{SAFE}""", pg='06 / 07')
S[p.format(7)] = p7q('收藏起來，<br>慢慢聞、<br>慢慢挑', '留言告訴我：<br>你最想先認識哪一株植物？', '傳給每次都問你<br>用什麼油的那位朋友')

# 11/06 FB 方圖
S['W45/W45_1106_FB方圖_香氣從植物的哪裡來.png'] = page(
    f"""<div class="serif" style="font-size:64px;line-height:1.25">這個香氣，<br>從植物的哪裡來？</div>
    <div style="display:flex;flex-direction:column;gap:22px;margin-top:44px">""" + ''.join(
    f'<div class="row" style="gap:28px"><div class="serif" style="flex:none;width:330px;background:{C["sage"]};color:#fff;border-radius:20px;padding:18px 24px;font-size:42px">{a}</div><div class="sub" style="font-size:38px">{b}</div></div>'
    for a, b in [('花・花穗', '薰衣草、依蘭'), ('枝葉', '尤加利、迷迭香、絲柏'), ('根・根莖', '岩蘭草、薑'), ('果皮・種子・漿果', '檸檬、甜茴香、杜松')]) +
    '</div>', 1080, 1080, C['linen'])

# 11/09 冬天留給自己的 5 瓶
p = 'W46/W46_1109_IG圖卡_1111囤貨清單_P{}.png'
S[p.format(1)] = page(f"""<div><span class="pill" style="background:#fff;color:{C['damber']}">1111 囤貨清單</span></div>
  <div class="serif h1" style="margin-top:60px">冬天，<br>我會留給<br>自己的 5 瓶</div>
  <div class="sub" style="margin-top:30px">每天會碰到的香氣選大瓶，<br>臉上的保養挑最需要的。</div>
  <div style="position:absolute;right:50px;bottom:110px">{img('breath250.png','height:600px')}</div>""", bg=C['sage'], fg=C['linen'], pg='01 / 07')
S[p.format(2)] = page(f"""<div class="pill" style="background:{C['damber']};color:#fff;align-self:flex-start">身體｜×2</div>
  <div class="serif h2" style="margin-top:40px">經典按摩油六款<br>250mL</div>
  <div class="body" style="margin-top:30px">一瓶明亮的、一瓶沉穩的。<br>我自己是清新舒緩<br>配暖身舒活。</div>
  <div style="position:absolute;right:70px;bottom:120px">{img('breath250.png','height:600px')}</div>""", pg='02 / 07')
S[p.format(3)] = page(f"""<div class="pill" style="background:{C['damber']};color:#fff;align-self:flex-start">夜晚｜×1</div>
  <div class="serif h2" style="margin-top:40px">一夜放鬆<br>250mL</div>
  <div class="body" style="margin-top:30px">冬天的夜晚，把燈調暗，<br>讓花香慢慢沉成木質。</div>
  {ingredient_rows([('薰衣草', '花穗'), ('馬鬱蘭', '枝葉'), ('岩蘭草', '根')])}""", pg='03 / 07')
S[p.format(5)] = page(f"""<div class="serif h2">怎麼配最順手？</div>
  <div class="body" style="margin-top:40px">☀️ 早上｜清新舒緩，洗完澡全身用<br>🕯️ 晚上｜一夜放鬆，肩頸、手臂<br>✨ 臉部｜化妝水 → B3 → 角鯊烷<br>　　　（杏仁酸 PHA 晚上隔天用，白天加強防曬）</div>{SAFE}""", pg='05 / 07')
S[p.format(7)] = p7q('收藏起來<br>當購物清單', '你今年 1111<br>最想補哪一瓶？', '傳給一起湊單的朋友，<br>清單直接對照')

# 11/10 Reels（本月唯一幕後篇）
S['W46/W46_1110_Reels封面_出貨前一晚.png'] = cover_reels('1111 前一晚，<br>我們把每一箱<br>再看一次', 'IG Reels｜1111 幕後', C['sage'], '#fff', img('breath250.png', 'height:720px'))
S['W46/W46_1110_Reels封面_出貨前一晚_B.png'] = cover_reels('明天打開箱子，<br>你會先聞到<br>什麼？', 'IG Reels｜1111 幕後', C['sage'], '#fff', img('breath250.png', 'height:720px'))

# 11/15 Reels 清新舒緩
S['W46/W46_1115_Reels封面_清新舒緩推開窗.png'] = cover_reels('這瓶油，<br>像冬天早上<br>推開窗', 'IG Reels｜認識植物', C['frost'], C['white'], img('breath250.png', 'height:760px'))
S['W46/W46_1115_Reels封面_清新舒緩推開窗_B.png'] = cover_reels('尤加利的香氣，<br>藏在葉子裡', 'IG Reels｜認識植物', C['frost'], C['white'], img('breath250.png', 'height:760px'))

# 11/17 Reels
S['W47/W47_1117_Reels封面_睡前3分鐘.png'] = cover_reels('下班後 3 分鐘，<br>把一天<br>慢慢收起來', 'IG Reels｜小雪 11/22', C['sage'], C['linen'], img('chakra4.png', 'height:780px'))
S['W47/W47_1117_Reels封面_睡前3分鐘_B.png'] = cover_reels('芳療師自己<br>晚上會做的<br>3 分鐘', 'IG Reels｜小雪 11/22', C['sage'], C['linen'], img('chakra4.png', 'height:780px'))

# 11/19 七脈輪：去掉圖上「」
p = 'W47/W47_1119_IG圖卡_七脈輪香氣地圖_P{}.png'
S[p.format(5)] = page(f"""<div class="serif h2">入門怎麼挑？</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:60px"><div class="h3 serif">先選一款<br>你聞了會想多聞一下的</div></div>
  <div class="sub" style="margin-top:40px">不要選你覺得應該需要的。<br>香氣喜好本來就因人而異。</div>{SAFE}""", pg='05 / 07')
S[p.format(7)] = p7q('收藏<br>這張地圖', '留言你現在最想要的心情，<br>我幫你配一款', '傳給最近很需要<br>慢下來一下的朋友')

# 11/21 Reels 暖身舒活（無對應實拍瓶身 → 純文字＋植物部位）
ROOT = f'<div style="display:flex;flex-direction:column;gap:22px;align-items:center;color:{C["char"]}">' + ''.join(
    f'<div style="border:4px solid {C["sage"]};border-radius:999px;padding:18px 54px;font-size:52px" class="serif">{t}</div>' for t in ['薑｜根莖', '藍膠尤加利｜葉', '薄荷｜葉']) + '</div>'
S['W47/W47_1121_Reels封面_暖身舒活辛暖.png'] = cover_reels('小雪這天，<br>我會打開<br>最辛暖的那一瓶', 'IG Reels｜認識植物', C['oat'], C['char'], ROOT)
S['W47/W47_1121_Reels封面_暖身舒活辛暖_B.png'] = cover_reels('薑的香氣，<br>藏在土裡的<br>根莖', 'IG Reels｜認識植物', C['oat'], C['char'], ROOT)

# 11/26 P7、11/27 FB 方圖
S['W48/W48_1126_IG圖卡_回購Top5_P7.png'] = p7q('謝謝你<br>一直回來', '留言你的家人最愛<br>是哪一瓶', '傳給當初<br>推薦你用 MW 的那個人')
S['W48/W48_1127_FB方圖_謝謝你9年.png'] = page(
    f"""<div class="serif" style="font-size:76px;line-height:1.3;margin-top:30px">謝謝你，<br>陪我們走了<br>9 年</div>
    <div class="body" style="margin-top:44px">洗完澡的那幾分鐘<br>送給媽媽的那一瓶<br>行李箱裡的那個味道</div>
    <div class="serif" style="position:absolute;right:40px;bottom:-60px;font-size:560px;line-height:1;opacity:.18">9</div>""",
    1080, 1080, C['sage'], '#fff')

# ═════════ v5（11/3）Reels 改圖卡輪播 5P（Morris 指示：先改圖卡輪播發）═════════
def c5cover(title, kicker, bg, fg, art, pg='01 / 05'):
    return page(f"""<div><span class="pill" style="background:{fg};color:{bg}">{kicker}</span></div>
  <div class="serif h1" style="margin-top:56px;font-size:90px">{title}</div>
  <div style="position:absolute;left:0;right:0;bottom:110px;display:flex;justify-content:center">{art}</div>""", bg=bg, fg=fg, pg=pg)
def c5text(head, body, pg, extra='', art=''):
    a = f'<div style="position:absolute;left:0;right:0;bottom:110px;display:flex;justify-content:center">{art}</div>' if art else ''
    return page(f"""<div class="serif h1" style="font-size:88px">{head}</div><div class="h3" style="margin-top:44px;line-height:1.6">{body}</div>{extra}{a}""", pg=pg)
def c5end(title, ask, share, pg='05 / 05'):
    a = f'<div class="box" style="background:{C["sage"]};color:#fff;margin-top:56px"><div class="sub">💬 {ask}</div></div>' if ask else ''
    return page(f"""<div class="serif h1" style="margin-top:100px">{title}</div>{a}
  <div class="box" style="background:#fff;margin-top:28px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 {share}</div></div>
  <div class="small" style="margin-top:36px">🔗 商品連結在主頁｜限動也有連結貼紙</div>""", bg=C['oat'], pg=pg)
def steps(rows):
    return '<div style="flex:1;display:flex;flex-direction:column;gap:22px;margin:44px 0 40px">' + ''.join(
        f'<div class="box" style="flex:1;background:#fff;display:flex;align-items:center;gap:30px"><div class="serif" style="font-size:72px;color:{C["sage"]};width:70px">{i+1}</div><div class="sub">{t}</div></div>' for i, t in enumerate(rows)) + '</div>'
PROMO_NOTE = '<div class="note" style="margin-top:auto;margin-bottom:60px">實際優惠以蝦皮頁面為準｜限時價數量有限，賣完就恢復原價</div>'

p = 'W46/W46_1110_IG圖卡_每一箱再看一次_P{}.png'
S[p.format(1)] = c5cover('1111 前一晚，<br>我們把每一箱<br>再看一次', '1111 幕後', C['sage'], '#fff', img('breath250.png', 'height:620px'))
S[p.format(2)] = c5text('貼好標籤、<br>鎖緊瓶蓋、<br>放進紙箱。', '每一瓶出門前，<br>都會被我們再拿起來一次。', '02 / 05', art=img('breath250.png', 'height:520px'))
S[p.format(3)] = page(f"""<div class="serif h2">這些油明天<br>會去很多地方</div>{ingredient_rows([('浴室', '某個人洗完澡的那幾分鐘'), ('床頭', '某個人一天的尾聲'), ('禮物', '某個人準備送出去的心意')])}""", pg='03 / 05')
S[p.format(4)] = c5text('我們沒辦法<br>跟每一位見面', '只能在封箱前，<br>把每一瓶都再確認一次。', '04 / 05', art=img('breath250.png', 'height:520px'))
S[p.format(5)] = page(f"""<div class="serif h1" style="margin-top:80px">明天 11/11<br>整天都有<br>限時特賣場次</div>
  <div class="sub" style="margin-top:30px">時段看限動</div>
  <div class="box" style="background:{C['sage']};color:#fff;margin-top:40px"><div class="sub">💬 留言告訴我你在等哪一瓶</div></div>
  <div class="box" style="background:#fff;margin-top:24px;border:4px solid {C['sage']}"><div class="sub" style="color:{C['sage']}">📤 傳給也在等 1111 包裹的朋友</div></div>{PROMO_NOTE}""", bg=C['oat'], pg='05 / 05')

p = 'W46/W46_1115_IG圖卡_清新舒緩推開窗_P{}.png'
S[p.format(1)] = c5cover('這瓶油，<br>像冬天早上<br>推開窗', '認識植物｜清新舒緩', C['frost'], C['white'], img('breath250.png', 'height:640px'))
S[p.format(2)] = page(f"""<div class="serif h2">主香是<br>三種枝葉</div>{ingredient_rows([('尤加利', '枝葉'), ('迷迭香', '枝葉'), ('綠花白千層', '枝葉')])}""", pg='02 / 05')
S[p.format(3)] = c5text('清透、<br>帶一點涼意', '像樹林裡<br>剛下過雨。', '03 / 05', art=img('breath250.png', 'height:520px'))
S[p.format(4)] = page(f"""<div class="serif h2">我會這樣用</div>{steps(['洗完澡、身體還暖暖的時候', '取適量在掌心搓熱，先聞一下', '從手臂慢慢推開'])}{SAFE}""", pg='04 / 05')
S[p.format(5)] = c5end('收藏，<br>下次打開瓶蓋<br>想起這片樹林', '', '傳給喜歡森林味道的朋友')

p = 'W47/W47_1117_IG圖卡_下班後3分鐘_P{}.png'
S[p.format(1)] = c5cover('下班後 3 分鐘，<br>把一天<br>慢慢收起來', '芳療師說｜七脈輪', C['sage'], C['linen'], img('chakra4.png', 'height:640px'))
S[p.format(2)] = page(f"""<div class="serif h2">先把燈<br>調暗一點</div>{steps(['關掉大燈，只留一盞小燈', '取適量七脈輪按摩油在掌心，搓熱'])}""", pg='02 / 05')
S[p.format(3)] = page(f"""<div class="serif h2">再慢慢呼吸</div>{steps(['雙手靠近鼻子，慢慢吸氣、慢慢吐氣，重複 5 次', '把油輕輕推開在肩頸和手臂'])}{SAFE}""", pg='03 / 05')
S[p.format(4)] = c5text('這 3 分鐘<br>不是為了<br>什麼厲害的效果', '只是讓今天在這裡停一下。<br>今天想要哪一種心情，<br>就打開哪一瓶。', '04 / 05', art=group7)
S[p.format(5)] = c5end('收藏，<br>今晚就試試', '你晚上最想留給自己的<br>是哪一段時間？', '傳給最近都很晚下班的朋友')

p = 'W47/W47_1121_IG圖卡_暖身舒活辛暖_P{}.png'
S[p.format(1)] = page(f"""<div><span class="pill" style="background:{C['char']};color:{C['oat']}">認識植物｜暖身舒活</span></div>
  <div class="serif h1" style="margin-top:56px;font-size:90px">小雪這天，<br>我會打開<br>最辛暖的那一瓶</div>
  <div style="position:absolute;left:0;right:0;bottom:120px;display:flex;justify-content:center">{ROOT}</div>""", bg=C['oat'], fg=C['char'], pg='01 / 05')
S[p.format(2)] = page(f"""<div class="serif h2">主香來自<br>植物的哪裡</div>{ingredient_rows([('薑', '根莖'), ('藍膠尤加利', '葉'), ('薄荷', '葉')])}""", pg='02 / 05')
S[p.format(3)] = c5text('辛暖在前，<br>清涼收在後面', '像冬天廚房裡<br>剛切開的一塊薑。', '03 / 05', art=ROOT)
S[p.format(4)] = page(f"""<div class="serif h2">冷天洗完澡</div>{steps(['取適量在掌心搓熱', '先聞一下', '從小腿輕輕推開'])}{SAFE}""", pg='04 / 05')
S[p.format(5)] = c5end('收藏，<br>冷天的晚上<br>用得到', '', '傳給喜歡辛香料味道的朋友')


def main(only=None):
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        for fn, html in S.items():
            if only and only not in fn:
                continue
            out = OUT / fn
            out.parent.mkdir(parents=True, exist_ok=True)
            w = int(html.split('--w:')[1].split('px')[0]); h = int(html.split('--h:')[1].split('px')[0])
            pg = b.new_page(viewport={'width': w, 'height': h})
            pg.set_content(html, wait_until='load')
            pg.wait_for_timeout(250)
            pg.screenshot(path=str(out), clip={'x': 0, 'y': 0, 'width': w, 'height': h})
            pg.close()
        b.close()
    print(len(S), 'defined')

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else None)
