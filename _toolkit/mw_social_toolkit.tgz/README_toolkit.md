# MW 社群圖文工具包 v1.0（2026-11-04）
每週排程「MW 社群｜每週備稿＋發文」在新 session 裡還原這包即可用同一套版型出圖。

## 還原
mkdir -p ~/social && cd ~/social && tar xzf mw_social_toolkit.tgz
pip install pillow --break-system-packages  # playwright/chromium 已預裝；字型 Noto Sans/Serif CJK TC（缺則 apt-get install fonts-noto-cjk）

## 檔案
- render.py：共用版型（page/img/C 色票/SAFE 安全提醒/c5cover/c5text/steps/ingredient_rows/PROMO_NOTE/group7/CHAKRA）。import 不會出圖，只有 __main__ 會重出 11 月。
- render_dec.py：12 月 + 共用 helper（end/item/promo_cover/sq/SAFE_S/OFF/B/Bs/chak）。
- render_jan.py：1 月範本（最新寫法，新月份複製這支改）。輸出 out/<YYYY/>Wxx/…png
- copy_v4.py（SAFE/SAFE1/PROMO/IGEND/FBEND 結尾句）、copy_dec.py、copy_jan.py：文案 P 清單（date, week, plat, fmt, exp, orig, title, hookA, share, ig, fb）。
- gate_jan.py：圖文閘門 V1–V12（色票、禁語、價格白名單 PRICE_OK、安全提醒、V9 去背圖白名單 breath250/chakra1–7）。新月份複製並改 import 與 PRICE_OK。
- mw_lint.py：文案紅黃燈（verdict 通過/待檢/未過）。
- build_review.py：python build_review.py copy_X render_X gate_X_result.json 輸出.html "標題" "說明"
- cut/：唯一可用的實物去背圖（經典 250mL 瓶、七脈輪 1–7）。AirTouch/PlantSilk/PURA+/單方沒有去背圖 → 不放瓶身，或標「需實拍」。
- 產品故事庫_社群版.md：真實配方、情緒文案素材、節氣節慶日曆（第 9 節）。

## 流程
copy_X.py → mw_lint → render_X.py → gate_X.py（全部 PASS）→ build_review.py → Artifact 發布審查頁 → Notion 佇列 狀態=待審

## v6 規則（2026-11-04 Morris 指示）
- 每則文案恰有一段「💡 精油小知識｜…」（可驗證的一般芳療知識，不談功效）。
- 敏感話題（睡眠、紓壓／情緒、身體部位舒緩、冷／暖身、大腦與嗅覺科學、精油濃度安全）＝純知識貼文：不寫商品名、價格、導流結尾、商品 hashtag，圖上不放瓶身，佇列導流連結清空；mw_lint 的「缺固定結尾」CHECK 對這類貼文豁免。
- kp.py（KP 字典、SENS 清單、FULL 全文改寫）→ kp_gate.py（K1 知識點、K2 敏感不連結、K3 lint）→ render_kp.py（敏感貼文圖：end_s 無商品連結、kpcard 知識卡）→ build_review_kp.py。
- 圖片網址一律用 GitHub raw：https://raw.githubusercontent.com/flymorris1230-ship-it/mw-social-assets/main/<路徑>（jsdelivr 因圖庫超過 50MB 已全面 403，不可再用）。
