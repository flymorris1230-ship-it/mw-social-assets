#!/usr/bin/env python3
"""MW精油工坊 文案法規紅線掃描 v1.0（2026-11-03）— 專案 claude/mw_lint.py 的本機副本"""
import re, sys, json, argparse

RED = [
 (r"治療|治癒|醫治|療效|根治|診斷|處方", "醫療效能（準則§5）"),
 (r"預防(?!乾燥|肌膚乾|皮膚乾)", "預防疾病＝醫療效能（準則§5；P0）"),
 (r"消炎|抑炎|發炎|紅腫|消腫|止痛|疼痛|痠痛|酸痛|止癢|僵硬|抽筋", "醫療效能／症狀（附件四10；P0）"),
 (r"殺菌|抑菌|抗菌|黴菌|感染|病毒", "醫療效能（附件四9、11；抗菌需試驗數據，MW 一律不寫）"),
 (r"修復|換膚|除疤|去疤|痘疤|疤痕|瘀斑|瘀青|狐臭|除毛|脫毛|生髮", "醫療效能（附件四）"),
 (r"藥用|藥效|藥劑|藥水|藥皂|醫藥級|鎮靜劑|鎮定劑", "藥品效能（附件一33–34、附件四20）"),
 (r"失眠|助眠|好眠|安眠|舒眠|入睡|好睡|睡得(更)?好|一覺到天亮|安神", "睡眠＝生理機能／醫療（P0）"),
 (r"焦慮|憂鬱|情緒障礙|頭痛|偏頭痛|經痛|生理痛|經期|更年期|荷爾蒙|內分泌|便秘|脹氣|感冒|鼻塞|過敏", "疾病、症狀或過敏宣稱（準則§5；附件一32）"),
 (r"排水|利尿|發汗|淨化身心|免疫|排毒|毒素|祛濕|排濕|寒氣|濕氣|氣血|經絡|穴道|手腳冰冷", "生理機能／療效暗示（附件一7；P0）"),
 (r"循環|淋巴|引流|代謝|細胞|膠原蛋白|毛囊|神經醯胺", "影響生理機能（附件一）"),
 (r"燃脂|燃燒脂肪|脂肪|去脂|減脂|消脂|瘦身|減肥|纖體|孅體|塑身|雕塑|緊實曲線|掰掰肉|蝴蝶袖|小腹|橘皮", "改變身體結構（附件一22–28）"),
 (r"豐胸|隆乳|堅挺|托高|集中", "改變身體結構（附件一29）"),
 (r"浮腫|水腫|放鬆肌肉|肌肉牽引", "生理機能（附件一15、31）"),
 (r"妊娠紋|肥胖紋|淡化紋路", "生理機能（附件一21）"),
 (r"滲透|深入肌底|直達肌底|\d+\s*秒\S{0,4}吸收|秒吸收|瞬間吸收", "滲透／吸收速度宣稱（P0）"),
 (r"提神|振奮精神|精力充沛|增強記憶", "非化粧品效能（P0）"),
 (r"防蚊|驅蚊|防蟲|驅蟲|淨化空氣|除臭空氣|消毒", "非化粧品範圍（環境用藥／準則§3-3）"),
 (r"孕婦(可用|安全|適用)|孕期(可用|安全)|嬰兒可用|寶寶可用", "絕對保證（P0）"),
 (r"零刺激|不刺激|無刺激|無副作用|不過敏|零過敏|低敏|抗敏", "絕對保證／過敏宣稱（附件一32）"),
 (r"100\s*%|百分之百|保證|永久|絕對|根除", "絕對保證（準則§3）"),
 (r"第一(?!次|則|張|頁|步|天|個|件|篇|批|瓶|週|周|名推廣)|最好|最有效|最強|最安全|最純|唯一|No\.?\s*1(?!\d)", "最高級無來源（P0 紅線5）"),
 (r"神油|神奇|奇蹟|秒殺效果|立即見效|見效", "虛偽誇大（準則§3）"),
 (r"醫師推薦|醫生推薦|醫師背書|醫師認證|專業醫師|醫學證實|臨床證實|臨床實驗|醫院|診所", "醫療背書／場景（P0 紅線7）"),
 (r"COSMOS|ECOCERT|有機認證|天然認證|無毒", "未取得的認證（P0：只能提 IFA／ISO 22716／台灣製造／產品登錄）"),
 (r"同一(個)?配方(基底)?|再加碼|最後一滴|主力按摩油目前分潤|\d+\s*[–\-~～]\s*\d+\s*滴", "撤回說法（Workflow v1.1 revoked_phrases）"),
 (r"一夜好眠|挺胸自信|美體曲線|淨脈舒緩|Sleepy|Full-?Breasted|Curve Sculpt|Muscle Warm", "舊品名（P0）"),
]

YELLOW = [
 (r"美白|淡斑|亮白|嫩白|抗老|延緩老化|老化|抗皺|皺紋|細紋|撫平", "需產品登錄成分／濃度支持（P0）"),
 (r"緊實|緊緻|彈性|修護|淨化|調理", "法規附件二可用，但需看修飾對象；MW 慎用"),
 (r"天然|有機|純天然|無添加|零添加|0\s*添加|無防腐劑|不含", "需原料證明／PIF（附件二註三、註四；P0 紅線3）"),
 (r"\d+(\.\d+)?\s*%|\d+\s*倍|\d+\s*天", "數字宣稱：分潤率、折扣以外需佐證（P0 紅線3）"),
 (r"舒緩(?=.{0,4}(痠|酸|痛|疼|肌肉|不適|疲勞))", "舒緩只能用在品名／香氣氛圍"),
 (r"放鬆(?=.{0,4}(肌肉|筋|神經|睡|身體|全身))", "放鬆只能修飾心情、氛圍、時光"),
 (r"舒緩|放鬆", "確認修飾對象是心情／氛圍／品名"),
 (r"疲勞|疲憊|疲倦|壓力|紓壓|舒壓", "附件二只接受『使用時散發淡淡○○香氣，可舒緩您的壓力』這類句型"),
 (r"能量|療癒|脈輪的作用|靈性|磁場", "品牌規範：七脈輪只講香氣選擇地圖"),
 (r"敏感肌|孕|哺乳|嬰幼兒|兒童", "需搭配『先局部測試／先諮詢醫師』"),
 (r"吸收|專注|記憶|睡前|睡", "看上下文：不得變成生理或睡眠宣稱"),
 (r"最便宜|CP值最高", "只能用在同品牌不同容量每 mL 比較並附數字"),
 (r"(?<!\d)\d{1,2}:\d{2}(?!\d)", "寫死的時段：須對照限時特賣排程（Workflow v1.1 G1）"),
 (r"評價|好評|客人說|買家說|回饋說", "評價引用：只能用評價 DB 原文、遮蔽帳號"),
]

def scan(text, kind):
    hits = {"RED": [], "YELLOW": [], "CHECK": []}
    red_spans = []
    for pat, why in RED:
        for m in re.finditer(pat, text, flags=re.I):
            hits["RED"].append({"詞": m.group(0), "位置": m.start(), "依據": why, "上下文": text[max(0,m.start()-10):m.end()+10].replace("\n"," ")})
            red_spans.append((m.start(), m.end()))
    seen = set()
    for pat, why in YELLOW:
        for m in re.finditer(pat, text, flags=re.I):
            if any(s <= m.start() < e for s, e in red_spans): continue
            key = (m.start(), m.group(0))
            if key in seen: continue
            seen.add(key)
            hits["YELLOW"].append({"詞": m.group(0), "位置": m.start(), "依據": why, "上下文": text[max(0,m.start()-10):m.end()+10].replace("\n"," ")})
    uniq = {}
    for h in hits["YELLOW"]:
        uniq.setdefault(h["位置"], h)
    hits["YELLOW"] = sorted(uniq.values(), key=lambda h: h["位置"])
    usage = re.search(r"按一按|推一推|抹一抹|掌心|搓熱|塗抹|抹在|推開|往上推|按摩\S{0,3}(肩|頸|手|腳|小腿)|使用方法|步驟", text)
    if usage or kind == "Reels":
        for need, label in [(r"手臂內側", "安全提醒：手臂內側小面積試用"), (r"眼周", "安全提醒：避開眼周與黏膜"), (r"諮詢醫師", "安全提醒：孕期、哺乳期或特殊體質請先諮詢醫師")]:
            if usage and not re.search(need, text): hits["CHECK"].append(f"缺 {label}")
    if re.search(r"孕|哺乳|嬰", text) and not re.search(r"諮詢醫師", text):
        hits["CHECK"].append("提到孕期／哺乳／嬰幼兒但沒有『請先諮詢醫師』")
    if re.search(r"\$|元|折|優惠|限時價|入\s*\d{3}|任選", text) and not re.search(r"實際優惠以蝦皮頁面為準", text):
        hits["CHECK"].append("檔期／價格文缺『實際優惠以蝦皮頁面為準』")
    if re.search(r"限時價|限時特賣", text) and not re.search(r"限時價數量有限", text):
        hits["CHECK"].append("限時價缺『限時價數量有限，賣完就恢復原價』")
    if re.search(r"（填入|\(填入|⚠️", text):
        hits["CHECK"].append("仍有（填入）或 ⚠️ → 合規檢查只能標『待檢』")
    if re.search(r"划算", text) and not re.search(r"每\s*mL|每\s*毫升", text):
        hits["CHECK"].append("『划算』沒有附每 mL 單價比較（P0 紅線5）→ 補數字或刪除")
    tags = re.findall(r"#\S+", text)
    if kind == "IG":
        if len(tags) > 5: hits["CHECK"].append(f"IG hashtag {len(tags)} 個，上限 5")
        if "商品連結在主頁" not in text: hits["CHECK"].append("IG 缺固定結尾『🔗 商品連結在主頁｜限動也有連結貼紙』")
    if kind == "FB":
        if not (4 <= len(tags) <= 5): hits["CHECK"].append(f"FB hashtag {len(tags)} 個，規範 4–5")
        if "第一則留言" not in text: hits["CHECK"].append("FB 缺固定結尾『👇 蝦皮連結放在第一則留言…』")
    if kind == "圖上字" and re.search(r"[「」『』]", text):
        hits["CHECK"].append("圖上字不使用「」引號")
    return hits

def verdict(h):
    if h["RED"]: return "未過"
    if any("填入" in c for c in h["CHECK"]): return "待檢"
    if h["CHECK"]: return "未過"
    return "通過（YELLOW 項需人工確認上下文）" if h["YELLOW"] else "通過"

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("file"); ap.add_argument("--type", default="IG"); ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    text = sys.stdin.read() if a.file == "-" else open(a.file, encoding="utf-8").read()
    h = scan(text, a.type)
    print(json.dumps({"判定": verdict(h), **h}, ensure_ascii=False, indent=1) if a.json else f"判定：{verdict(h)}")
