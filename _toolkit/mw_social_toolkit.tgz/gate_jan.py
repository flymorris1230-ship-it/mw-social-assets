# -*- coding: utf-8 -*-
"""MW 圖檔自動閘門（V1–V9）。任何 BLOCK = 不可送 QSA。
用法：python3 gate.py → 產出 gate_result.csv / gate_result.json"""
import re, json, csv, sys, html as H
from PIL import Image
sys.argv = [sys.argv[0], '__none__']   # 匯入 render 時不重新輸出
import render_jan as render
from render_jan import S, OUT

ALLOWED_SIZE = {(1080, 1350), (1080, 1080), (1080, 1920)}
PALETTE = {'#335C4F', '#F5F3F0', '#F4EEE6', '#E3D5C3', '#3A3A36', '#C4703E', '#A85A2C', '#8DA9B5', '#8A9A7B', '#FFFFFF'}
BAN = ['治療', '預防', '改善', '消炎', '止痛', '止癢', '抑菌', '殺菌', '排毒', '消腫', '水腫', '循環', '代謝', '燃脂', '瘦身',
       '塑身', '緊實', '豐胸', '助眠', '好眠', '失眠', '安神', '修復', '免疫', '滲透', '秒吸收', '妊娠紋', '美白', '淡斑', '抗老',
       '孕婦安全', '零刺激', '無副作用', '適合所有膚質', '第一名', '最好', '唯一', '最划算', '被動收入', '保證']
OLD_NAMES = ['一夜好眠', '挺胸自信', '美體曲線', '淨脈舒緩']
PRICE_OK = {'699', '396', '550', '899', '650', '999'}
REVOKED = [l.strip() for l in open('revoked_phrases.txt', encoding='utf-8') if l.strip() and not l.startswith('#')]
SAFE_KEYS = ['手臂內側', '避開眼周', '諮詢醫師']
USAGE_KEYS = ['掌心', '輕推', '按摩', '搓熱']

def text_of(h):
    body = h.split('<body>', 1)[1]
    body = re.sub(r'<img[^>]*>', ' ', body)
    t = re.sub(r'<br\s*/?>', '\n', body)
    t = re.sub(r'<[^>]+>', ' ', t)
    return re.sub(r'[ \t]+', ' ', H.unescape(t)).strip()

def corner_hex(path):
    im = Image.open(path).convert('RGB')
    r, g, b = im.getpixel((6, 6))
    return '#%02X%02X%02X' % (r, g, b)

def post_key(fn):
    m = re.match(r'(W\d+)/(W\d+_\d{4}_[^_]+_[^_]+?)(_P\d+)?\.png$', fn)
    return m.group(2) if m else fn

rows = []
groups = {}
for fn, h in S.items():
    groups.setdefault(post_key(fn), []).append(fn)

for fn, h in S.items():
    t = text_of(h)
    issues, block = [], False
    path = OUT / fn
    size = Image.open(path).size
    if size not in ALLOWED_SIZE:
        issues.append(f'V1 尺寸 {size}'); block = True
    ch = corner_hex(path)
    if ch not in PALETTE:
        issues.append(f'V2 底色 {ch} 不在 v3 色票'); block = True
    for w in BAN:
        if w in t:
            issues.append(f'V3 禁用詞「{w}」'); block = True
    for w in OLD_NAMES:
        if w in t:
            issues.append(f'V3 舊品名「{w}」'); block = True
    for w in REVOKED:
        if w in t:
            issues.append(f'V10 已撤回說法「{w}」'); block = True
    if '（填入' in t or '⚠️' in t:
        issues.append('V4 含（填入）／⚠️ 占位符'); block = True
    nums = set(re.findall(r'(?<![\d.])(\d{3,4})(?![\d.]|mL|ml| 年| 位|\s*化粧品)', t)) - {'1111', '1212', '2026', '2027', '22716', '1103'}
    bad = [n for n in nums if n not in PRICE_OK]
    if bad:
        issues.append(f'V5 未核對數字 {bad}'); block = True
    if re.search(r'\b\d{1,2}:\d{2}\b', t):
        issues.append('V6 含場次時段（11/11 場次未定，不可寫死）'); block = True
    if any(p in t for p in PRICE_OK) and '以蝦皮' not in t and '單買' not in t:
        # 價格頁必須同頁有「實際優惠以蝦皮頁面為準」或屬同組圖卡另頁已註明
        sib = ''.join(text_of(S[x]) for x in groups[post_key(fn)])
        if '以蝦皮' not in sib:
            issues.append('V7 價格頁缺「實際優惠以蝦皮頁面為準」'); block = True
    sib = ''.join(text_of(S[x]) for x in groups[post_key(fn)])
    if any(k in sib for k in USAGE_KEYS) and len(groups[post_key(fn)]) > 1 and not all(k in sib for k in SAFE_KEYS):
        issues.append('V8 使用方法圖卡缺安全提醒'); block = True
    # V12 UGC 授權：評價／客人內容圖卡須有評價 DB 授權編號
    if re.search(r'回購Top5_P[2-6]|客人的油|UGC', fn) and '授權#' not in t:
        issues.append('V12 UGC 圖卡缺評價 DB 授權編號（授權#）'); block = True
    imgs = re.findall(r'base64,([A-Za-z0-9+/=]{20})', h)
    # V9 商品圖來源：只允許實拍去背白名單（render.img 只讀 cut/ 內檔案）
    srcs = re.findall(r"img\('([^']+)'", open('render_jan.py', encoding='utf-8').read())
    wl = {'breath250.png'} | {f'chakra{i}.png' for i in range(1, 8)}
    if not set(s for s in srcs if s.endswith('.png') and '{' not in s) <= wl:
        issues.append('V9 商品圖不在實拍白名單'); block = True
    rows.append(dict(檔名=fn, 貼文=post_key(fn), 尺寸=f'{size[0]}×{size[1]}', 底色=ch,
                     自動閘門='BLOCK' if block else 'PASS', 問題='；'.join(issues) or '—', 圖上文字=t.replace('\n', ' / ')))

with open('gate_jan_result.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
json.dump(rows, open('gate_jan_result.json', 'w'), ensure_ascii=False, indent=1)
p = sum(r['自動閘門'] == 'PASS' for r in rows)
print(f'{len(rows)} 張｜PASS {p}｜BLOCK {len(rows)-p}')
for r in rows:
    if r['自動閘門'] == 'BLOCK':
        print(r['檔名'], '→', r['問題'])

# ═════ 文案閘門（v4）：copy_v4 全文 → mw_lint（Workflow v2.0 S3 自動層）；圖上字也跑 mw_lint 圖上字模式 ═════
import copy_jan as copy_v4, mw_lint
crow = []
for p in copy_v4.P:
    for k, kind in (('ig', 'IG'), ('fb', 'FB')):
        if k in p:
            h = mw_lint.scan(p[k], kind)
            crow.append(dict(項目=f"{p['date']} {p['plat']} {kind}", 判定=mw_lint.verdict(h), RED='、'.join(x['詞'] for x in h['RED']) or '—',
                             YELLOW='、'.join(sorted(set(x['詞'] for x in h['YELLOW']))) or '—', CHECK='；'.join(h['CHECK']) or '—'))
for r in rows:
    h = mw_lint.scan(r['圖上文字'], '圖上字')
    if h['RED'] or any('引號' in c for c in h['CHECK']):
        r['自動閘門'] = 'BLOCK'; r['問題'] = (r['問題'] if r['問題'] != '—' else '') + '；lint 圖上字：' + '、'.join([x['詞'] for x in h['RED']] + [c for c in h['CHECK'] if '引號' in c])
json.dump(crow, open('gate_jan_copy_result.json', 'w'), ensure_ascii=False, indent=1)
json.dump(rows, open('gate_jan_result.json', 'w'), ensure_ascii=False, indent=1)
with open('gate_jan_result.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
print('圖檔（含 lint）', len(rows), '張｜PASS', sum(r['自動閘門'] == 'PASS' for r in rows))
for r in rows:
    if r['自動閘門'] == 'BLOCK': print(' ', r['檔名'], r['問題'])
print('文案', len(crow), '項')
for r in crow: print(' ', r['項目'], r['判定'], 'RED:', r['RED'], 'CHECK:', r['CHECK'])
